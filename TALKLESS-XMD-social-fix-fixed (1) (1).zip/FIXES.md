# TALKLESS ULTRA — fix pack (2026-11-11)

Server: panel.bwmxmd.co.ke / `talkless Server` (ae5cb508)
Scope: "Waiting for this message", dead pairing retries, session loss, Neon constraint crash.

## 1. `index.js` — sent messages now survive restarts

`getMessage` already existed for Baileys retry receipts, but the cache was
memory-only (`sock.__sentCache`). Any restart left the bot with nothing to
resend, so the recipient's phone stayed on *"Waiting for this message"* forever.

Added:
- `database/sent-cache.json` — up to 800 sent messages / 12 MB mirrored to disk,
  with each WhatsApp protobuf encoded in its wire format and decoded on load.
- `rememberSent()` / `queueSentSave()` / `persistSentStore()`.
- `sendMessage()` and `relayMessage()` are both cached, scoped by session, chat,
  and message ID. `sentMessageFor()` now resolves: memory → disk →
  `retrieveMessage()` fallback.

Result: a retry receipt that arrives minutes or hours later, even after a
restart, can still be answered with the original proto.

## 2. `helper/talkless-neon.js` — pairing no longer destroys sessions

Two changes:

- **Archive instead of delete.** A pairing request for a number that already had
  a `sessions/web_<phone>` folder used to call `deleteSession()`. Wiping
  `creds.json` orphans the phone's linked device: every message that device
  already sent becomes permanently undecryptable ("Waiting for this message").
  It is now moved to `sessions/.backup/<sessionId>_<timestamp>` (last 3 kept).
- **Abandoned sockets no longer block retries.** The guard
  `activeSockets.has(sessionId)` treated a half-finished pairing (expired code,
  closed page) as an active number and rejected every retry with
  *"This number is already connected."* It now only refuses when the socket is
  authenticated (`sock.user`); otherwise it ends the stale socket and pairs again.

## 3. `helper/web-session-import.js` — Neon NOT NULL crash

The table was created with `payload TEXT NOT NULL`, while `markConnected()`,
`markFailed()` and `expireStale()` all write `payload = NULL`. Every 8-second
tick failed with:

```
[WEB-IMPORT] expire: null value in column "payload" of relation
"talkless_session_imports" violates not-null constraint
```

Fix: column is now `payload TEXT`, plus a self-heal
`ALTER TABLE ... ALTER COLUMN payload DROP NOT NULL` inside `ensureTable()`
so older deployments repair themselves on boot. See `NEON-FIX.sql` for the
one-off migration already applied to the live database.

## Deploy

1. Upload `index.js`, `helper/talkless-neon.js`, `helper/web-session-import.js`
   over the existing files (keep `sessions/` and `database/` untouched).
2. Run `NEON-FIX.sql` once against the Neon database (already done on the live one).
3. Restart the server.
4. Re-link the WhatsApp number: phone → Linked devices → remove any stale
   "Ubuntu / Chrome" entry → pair again with a fresh code.

## Not fixable from the server

- **Existing "Waiting for this message" bubbles.** The message content only
  exists on the device that sent it. Once that device/session is gone there is
  nothing left to serve it, so the placeholder is permanent — delete the entry.
- **Duplicate bot instance.** The log repeats
  `TELEGRAM 409 Conflict ... only one bot instance is running`, proving a second
  process polls the same token. Two copies sharing one WhatsApp identity will
  keep producing undecryptable messages. Stop the other copy.
- **No paired number.** At hand-off `sessions/` is empty (`Reloading 0 session(s)`),
  so the bot answers nothing until the number is paired again.

## Troubleshooting hook

`.bwm-wrapper.js` (already on the server) tees the console to
`logs/console-YYYY-MM-DD.log`, which is how these faults were read without
panel console access. Delete that file to return to a plain `node index.js`
startup; it is picked up automatically by the egg startup command.
