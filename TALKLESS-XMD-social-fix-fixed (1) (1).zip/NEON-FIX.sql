-- TALKLESS ULTRA — Neon fix for talkless_session_imports (2026-11-11)
-- Symptom it removes, once per 8s in the panel console:
--   [WEB-IMPORT] expire: null value in column "payload" of relation
--   "talkless_session_imports" violates not-null constraint
--
-- Cause: the table was created with payload NOT NULL, while markConnected(),
-- markFailed() and expireStale() intentionally write payload = NULL to wipe the
-- credential after use.
--
-- Safe to re-run. Already applied to the live TALKLESS database on 2026-11-11.

-- 1. Allow the credential to be wiped.
ALTER TABLE talkless_session_imports ALTER COLUMN payload DROP NOT NULL;

-- 2. Finish the cleanups that had been failing every tick.
UPDATE talkless_session_imports
   SET payload = NULL
 WHERE payload IS NOT NULL
   AND status <> 'pending';

UPDATE talkless_session_imports
   SET status = 'expired', payload = NULL, updated_at = now()
 WHERE status = 'pending'
   AND expires_at <= now();

-- 3. Verify.
SELECT column_name, is_nullable
  FROM information_schema.columns
 WHERE table_name = 'talkless_session_imports'
   AND column_name = 'payload';

SELECT status, count(*) FROM talkless_session_imports GROUP BY status;
