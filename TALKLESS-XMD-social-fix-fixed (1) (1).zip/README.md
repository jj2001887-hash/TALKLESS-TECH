# 🦅 TALKLESS XMD

### WhatsApp automation with Telegram-based control

TALKLESS XMD connects a WhatsApp session to a Telegram control bot. Telegram commands are used to manage the paired WhatsApp session and its automation features.

## Main components

- **WhatsApp connection:** Baileys multi-file session authentication.
- **Telegram control:** Telegraf bot interface.
- **Session management:** Pairing and session restore helpers.
- **Automation:** Message handlers, group tools, media utilities, and configurable features.

## Requirements

- Node.js 22
- A Telegram bot token from [@BotFather](https://t.me/BotFather)
- A Telegram numeric owner ID
- WhatsApp pairing credentials
- Optional PostgreSQL/Neon database and GitHub backup credentials, depending on enabled features

## Local setup

1. Extract the project.
2. Install dependencies with `npm ci`.
3. Set the environment variables listed below.
4. Start the bot with `npm start`.

## Environment variables

| Variable | Required | Purpose |
|---|---|---|
| `TELEGRAM_TOKEN` | Yes | Telegram bot token |
| `OWNER_TELEGRAM_ID` | Yes | Telegram numeric ID authorized as owner |
| `NEON_DATABASE_URL` | If using web pairing/database features | PostgreSQL connection string |
| `GITHUB_TOKEN` | If using GitHub session backup | GitHub token with access only to the private backup repository |
| `GITHUB_USERNAME` | If using GitHub session backup | GitHub account or organization |
| `GITHUB_REPO` | If using GitHub session backup | Private repository used for session backup |
| `GITHUB_BRANCH` | No | Backup branch; defaults to `main` |

Never commit `.env`, Telegram tokens, database passwords, WhatsApp session files, or backup tokens to GitHub. Add secrets through Heroku **Settings → Config Vars**.

## Heroku deployment

This project includes a `Procfile` with a background worker:

```procfile
worker: npm start
```

Deploy the repository to Heroku, configure the required Config Vars, then enable one worker dyno. A continuously running worker requires a paid Heroku dyno plan.

## WhatsApp session persistence

Heroku dyno filesystems are ephemeral. Configure and test the project's private session-backup mechanism before relying on restarts or redeployments. Keep the backup repository private and restrict its token permissions.

## Troubleshooting

- Check Heroku logs for missing environment variables or dependency errors.
- Confirm only one instance is polling the same Telegram bot token.
- If WhatsApp reconnects after a restart, verify the session restore/backup flow.
- `Waiting for this message` can be caused by WhatsApp encryption/session synchronization. The bot keeps a bounded sent-message retry cache, but no bot can guarantee recovery if WhatsApp does not supply the required keys or the stored message is unavailable.

## Project

**Name:** TALKLESS XMD  
**Platform:** WhatsApp + Telegram  
**Runtime:** Node.js 22  
**Process:** Heroku worker
