'use strict';

// Per-socket anti-delete recovery. Each paired WhatsApp socket gets its own
// cache and recovered messages are sent only to that socket's private JID.
const { getWaSettings, retrieveMessage } = require('./function');
const { normNum } = require('./groupAdmin');
const { logInfo, logError, logWarn } = require('./logger');

const MAX_CACHE = 3000;
const states = new WeakMap();

function stateFor(sock) {
  let state = states.get(sock);
  if (!state) {
    state = { cache: new Map(), byId: new Map(), recovered: new Set(), names: new Map(), pushNames: new Map(), lidToPn: new Map() };
    states.set(sock, state);
  }
  return state;
}

// Recovered messages always go to the paired number's own private chat.
// The logged-in account (sock.user.id) is the source of truth; the session
// name is only a fallback while the socket is still connecting.
function pairedJid(sock) {
  const fromUser = normNum(sock?.user?.id || '');
  const number = /^\d{7,}$/.test(fromUser) ? fromUser : normNum(sock?.__waNum || '');
  return /^\d{7,}$/.test(number) ? `${number}@s.whatsapp.net` : null;
}

function unwrap(message) {
  let value = message || {};
  for (let i = 0; i < 6; i++) {
    const wrapper = [
      'ephemeralMessage', 'viewOnceMessage', 'viewOnceMessageV2',
      'viewOnceMessageV2Extension', 'documentWithCaptionMessage',
    ].find(name => value?.[name]?.message);
    if (!wrapper) break;
    value = value[wrapper].message;
  }
  return value;
}

function contentType(message) {
  return Object.keys(message || {}).find(type => ![
    'senderKeyDistributionMessage', 'messageContextInfo', 'protocolMessage',
    'reactionMessage',
  ].includes(type));
}


// ── Identity: real number + saved name / profile name ─────────
const digitsOf = (jid) => String(jid || '').split('@')[0].split(':')[0].replace(/\D/g, '');
const isLid = (jid) => /@lid$/.test(String(jid || ''));

function rememberPair(state, lid, pn) {
  const l = digitsOf(lid), p = digitsOf(pn);
  if (l && p && l !== p && /^\d{7,15}$/.test(p)) state.lidToPn.set(l, p);
}

// Called from contact / history events: remembers the name saved in the
// owner's address book (contact.name) and the profile name (contact.notify).
function recordContacts(sock, list) {
  try {
    const state = stateFor(sock);
    for (const c of Array.isArray(list) ? list : []) {
      if (!c) continue;
      const ids = [c.id, c.jid, c.lid, c.phoneNumber].filter(Boolean);
      const saved = c.name || c.verifiedName || '';
      const push = c.notify || '';
      for (const id of ids) {
        const d = digitsOf(id);
        if (!d) continue;
        if (saved) state.names.set(d, saved);
        if (push) state.pushNames.set(d, push);
      }
      const pn = [c.jid, c.phoneNumber, c.id].find(v => v && !isLid(v));
      const lid = [c.lid, c.id].find(v => v && isLid(v));
      if (pn && lid) rememberPair(state, lid, pn);
    }
  } catch (error) { logWarn('AntiDelete', `contact record failed: ${error.message}`); }
}

function recordLidMapping(sock, update) {
  try {
    const list = Array.isArray(update) ? update : [update];
    for (const u of list) rememberPair(stateFor(sock), u?.lid, u?.pn || u?.phoneNumber);
  } catch {}
}

// Resolve a jid (maybe a hidden @lid id) to a real phone number.
async function resolveNumber(sock, jid, hints = [], groupJid = null) {
  if (!jid) return '';
  const state = stateFor(sock);
  if (!isLid(jid)) return digitsOf(jid);
  const lid = digitsOf(jid);
  for (const h of hints) if (h && !isLid(h)) return digitsOf(h);
  if (state.lidToPn.has(lid)) return state.lidToPn.get(lid);
  try {
    const fn = sock.signalRepository?.lidMapping?.getPNForLID;
    if (typeof fn === 'function') {
      const pn = await fn.call(sock.signalRepository.lidMapping, jid);
      if (pn) { rememberPair(state, jid, pn); return digitsOf(pn); }
    }
  } catch {}
  if (groupJid) {
    try {
      const meta = await sock.groupMetadata(groupJid);
      for (const p of meta.participants || []) {
        const pn = [p.phoneNumber, p.jid, p.id].find(v => v && !isLid(v));
        const pl = [p.lid, p.id].find(v => v && isLid(v));
        if (pn && pl) rememberPair(state, pl, pn);
      }
      if (state.lidToPn.has(lid)) return state.lidToPn.get(lid);
    } catch {}
  }
  return '';
}

function displayIdentity(sock, jid, number, pushHint = '') {
  const state = stateFor(sock);
  const keys = [digitsOf(jid), number].filter(Boolean);
  let savedName = '', pushName = pushHint || '';
  for (const k of keys) {
    savedName ||= state.names.get(k) || '';
    pushName ||= state.pushNames.get(k) || '';
  }
  const phone = number ? `+${number}` : 'number hidden by WhatsApp';
  if (savedName) {
    return { line: `${savedName}${pushName && pushName !== savedName ? ` (~${pushName})` : ''}`, phone, saved: true };
  }
  return { line: pushName ? `~${pushName} (not saved)` : 'Unknown (not saved)', phone, saved: false };
}

function formatWhen(ts) {
  const d = new Date(ts);
  return d.toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'medium' });
}

function saveMessage(sock, message) {
  try {
    if (!message?.message || !message.key?.id) return;
    if (message.key.remoteJid === 'status@broadcast') return;
    if (message.message.protocolMessage) return;

    const state = stateFor(sock);
    if (!message.key.fromMe) {
      const who = message.key.participant || message.key.remoteJid;
      if (message.pushName) state.pushNames.set(digitsOf(who), message.pushName);
      const pnHint = [message.key.participantPn, message.key.participantAlt, message.key.remoteJidAlt].find(v => v && !isLid(v));
      if (pnHint && isLid(who)) rememberPair(state, who, pnHint);
    }
    const key = `${message.key.remoteJid}|${message.key.id}`;
    state.cache.set(key, {
      key: { ...message.key },
      message: message.message,
      pushName: message.pushName || '',
      time: Date.now(),
    });
    state.byId.set(message.key.id, key);
    if (state.cache.size > MAX_CACHE) {
      const oldest = state.cache.keys().next().value;
      const old = state.cache.get(oldest);
      state.cache.delete(oldest);
      if (old?.key?.id && state.byId.get(old.key.id) === oldest) state.byId.delete(old.key.id);
    }
  } catch (error) {
    logWarn('AntiDelete', `save failed: ${error.message}`);
  }
}

async function downloadMedia(sock, message, key) {
  const baileys = require('blacklord-baileys');
  const logger = { info(){}, error(){}, warn(){}, debug(){}, child(){ return this; } };
  try {
    return await baileys.downloadMediaMessage(
      { key, message }, 'buffer', {}, { logger, reuploadRequest: sock.updateMediaMessage }
    );
  } catch (firstError) {
    const type = contentType(message);
    const contentTypeName = type ? type.replace(/Message$/, '').toLowerCase() : null;
    if (!contentTypeName || typeof baileys.downloadContentFromMessage !== 'function') throw firstError;
    const stream = await baileys.downloadContentFromMessage(message[type], contentTypeName);
    const chunks = [];
    for await (const chunk of stream) chunks.push(Buffer.from(chunk));
    return Buffer.concat(chunks);
  }
}

function getSaved(sock, key) {
  const state = stateFor(sock);
  return state.cache.get(`${key?.remoteJid}|${key?.id}`) ||
    state.cache.get(state.byId.get(key?.id)) ||
    retrieveMessage(key?.remoteJid, key?.id, sock.__waNum || 'default');
}

function deleteKeyFrom(input) {
  if (input?.key?.id) return input.key;
  if (input?.update?.message?.protocolMessage?.key) return input.update.message.protocolMessage.key;
  if (input?.update?.protocolMessage?.key) return input.update.protocolMessage.key;
  if (input?.message?.protocolMessage?.key) return input.message.protocolMessage.key;
  return null;
}

async function recoverOne(sock, key) {
  const owner = pairedJid(sock);
  if (!owner || !key?.id || key.fromMe) return;

  const state = stateFor(sock);
  const recoveryKey = key.id;
  if (state.recovered.has(recoveryKey)) return;
  state.recovered.add(recoveryKey);
  if (state.recovered.size > 10000) state.recovered.clear();

  const saved = getSaved(sock, key);
  if (!saved || saved.key.fromMe) return;

  const chatJid = saved.key.remoteJid;
  const isGroup = String(chatJid).endsWith('@g.us');
  const sender = saved.key.participant || chatJid;
  const deleter = key.participant || (isGroup ? sender : chatJid);
  let content = unwrap(saved.message);
  const type = contentType(content);
  if (!type) return;

  const senderHints = [saved.key.participantPn, saved.key.participantAlt, saved.key.remoteJidAlt];
  const senderNumber = await resolveNumber(sock, sender, senderHints, isGroup ? chatJid : null);
  const who = displayIdentity(sock, sender, senderNumber, saved.pushName);

  let deleterLine = null;
  if (digitsOf(deleter) !== digitsOf(sender)) {
    const deleterNumber = await resolveNumber(sock, deleter, [key.participantPn, key.participantAlt], isGroup ? chatJid : null);
    const d = displayIdentity(sock, deleter, deleterNumber);
    deleterLine = `🧹 *Deleted by:* ${d.line}\n📞 *Their number:* ${d.phone}`;
  }

  let chatLine;
  if (isGroup) {
    let subject = 'Unknown group';
    try { subject = (await sock.groupMetadata(chatJid)).subject || subject; } catch {}
    chatLine = `👥 *Group:* ${subject}`;
  } else {
    chatLine = `💬 *Chat:* Private chat with ${who.line}`;
  }

  const header =
    `🗑️ *ANTI-DELETE*\n` +
    `━━━━━━━━━━━━━━━\n` +
    `${chatLine}\n` +
    `👤 *Sender:* ${who.line}\n` +
    `📞 *Number:* ${who.phone}\n` +
    (deleterLine ? `${deleterLine}\n` : '') +
    `🕒 *Sent:* ${formatWhen(saved.time)}\n` +
    `🗑 *Deleted:* ${formatWhen(Date.now())}\n` +
    `━━━━━━━━━━━━━━━\n`;
  const mentions = [];
  const fail = async label => sock.sendMessage(owner, { text: `${header}\n📦 *Deleted ${label}* (media unavailable)`, mentions });

  try {
    logInfo('AntiDelete', `recovering ${type} for ${owner}`);
    if (type === 'conversation' || type === 'extendedTextMessage') {
      const text = content.conversation || content.extendedTextMessage?.text || '';
      await sock.sendMessage(owner, { text: `${header}📝 *Message:*\n${text}`, mentions });
      return;
    }

    if (['imageMessage', 'videoMessage', 'audioMessage', 'stickerMessage', 'documentMessage'].includes(type)) {
      const buffer = await downloadMedia(sock, content, saved.key).catch(() => null);
      if (!buffer) return fail(type.replace('Message', ''));
      const data = content[type] || {};
      const caption = `${header}${data.caption ? `\n📝 *Caption:* ${data.caption}` : ''}`;
      if (type === 'imageMessage') return sock.sendMessage(owner, { image: buffer, caption, mentions });
      if (type === 'videoMessage') return sock.sendMessage(owner, { video: buffer, caption, mentions });
      if (type === 'audioMessage') {
        await sock.sendMessage(owner, { text: header, mentions });
        return sock.sendMessage(owner, { audio: buffer, mimetype: data.mimetype || 'audio/mpeg', ptt: !!data.ptt });
      }
      if (type === 'stickerMessage') {
        await sock.sendMessage(owner, { text: header, mentions });
        return sock.sendMessage(owner, { sticker: buffer });
      }
      return sock.sendMessage(owner, { document: buffer, mimetype: data.mimetype || 'application/octet-stream', fileName: data.fileName || 'file', caption, mentions });
    }

    await sock.sendMessage(owner, { text: `${header}\n📦 *Type:* ${type}`, mentions });
  } catch (error) {
    logError('AntiDelete', error.message);
    await fail(type.replace('Message', '')).catch(() => {});
  }
}

async function handleDelete(sock, input) {
  const settings = getWaSettings(sock?.__waNum || '');
  if (!settings.antidelete) return;
  const keys = Array.isArray(input?.keys) ? input.keys : [deleteKeyFrom(input)].filter(Boolean);
  for (const key of keys) await recoverOne(sock, key);
}

async function handleDeleteUpdate(sock, updates) {
  const settings = getWaSettings(sock?.__waNum || '');
  if (!settings.antidelete) return;
  const list = Array.isArray(updates) ? updates : [updates];
  for (const entry of list) {
    const update = entry?.update || {};
    const protocol = update.message?.protocolMessage || update.protocolMessage || {};
    const type = protocol.type;
    // Baileys reports "delete for everyone" as messageStubType REVOKE (1) with
    // update.message === null, and the revoked id in entry.key.id.
    const stub = update.messageStubType;
    const isRevoke = Number(stub) === 1 || String(stub).toUpperCase() === 'REVOKE' ||
      String(type).toUpperCase() === 'REVOKE' || (protocol.key && Number(type) === 0);
    if (!isRevoke) continue;
    const revoked = protocol.key || entry.key;
    // entry.key.participant is who performed the delete; keep it.
    await recoverOne(sock, { ...revoked, participant: revoked.participant || entry.key?.participant });
  }
}

// Some builds deliver the revoke as a normal incoming protocolMessage.
async function handleRevokeUpsert(sock, m) {
  const protocol = m?.message?.protocolMessage ||
    m?.message?.ephemeralMessage?.message?.protocolMessage;
  if (!protocol?.key?.id) return;
  if (!(Number(protocol.type) === 0 || String(protocol.type).toUpperCase() === 'REVOKE')) return;
  const settings = getWaSettings(sock?.__waNum || '');
  if (!settings.antidelete) return;
  await recoverOne(sock, { ...protocol.key, participant: protocol.key.participant || m.key?.participant });
}

module.exports = { saveMessage, handleDelete, handleDeleteUpdate, handleRevokeUpsert, recordContacts, recordLidMapping };
