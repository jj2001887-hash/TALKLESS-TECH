'use strict';

function requestJid(request) {
  if (!request || typeof request !== 'object') return '';
  const keys = ['jid', 'participant', 'id', 'phoneNumber', 'phone_number'];
  for (const key of keys) {
    const value = String(request[key] || '').trim();
    if (value.includes('@')) return value;
  }
  for (const key of keys) {
    const digits = String(request[key] || '').replace(/\D/g, '');
    if (/^\d{7,15}$/.test(digits)) return `${digits}@s.whatsapp.net`;
  }
  return '';
}

function requestIdentities(request) {
  if (!request || typeof request !== 'object') return [];
  return ['jid', 'participant', 'id', 'phoneNumber', 'phone_number']
    .map(key => String(request[key] || '').trim())
    .filter(Boolean);
}

function findPendingRequest(pending, input) {
  if (!Array.isArray(pending)) return null;
  const raw = String(input || '').trim();
  const digits = raw.replace(/\D/g, '');
  return pending.find(request => {
    const identities = requestIdentities(request);
    if (raw.includes('@') && identities.some(value => value.toLowerCase() === raw.toLowerCase())) return true;
    return /^\d{7,15}$/.test(digits) && identities.some(value => value.replace(/\D/g, '') === digits);
  }) || null;
}

async function applyJoinRequestAction(sock, groupJid, jids, action, batchSize = 25) {
  const uniqueJids = [...new Set((Array.isArray(jids) ? jids : []).filter(jid => typeof jid === 'string' && jid.includes('@')))];
  const results = [];
  const errors = [];
  for (let start = 0; start < uniqueJids.length; start += batchSize) {
    const batch = uniqueJids.slice(start, start + batchSize);
    try {
      const response = await sock.groupRequestParticipantsUpdate(groupJid, batch, action);
      if (Array.isArray(response)) results.push(...response);
      else errors.push(`Unexpected response for ${batch.length} request(s).`);
    } catch (error) {
      errors.push(String(error?.message || error || 'Unknown request error').slice(0, 240));
    }
  }
  const succeeded = results.filter(result => String(result?.status || '') === '200').length;
  const failed = Math.max(uniqueJids.length - succeeded, 0);
  return { requested: uniqueJids.length, succeeded, failed, results, errors };
}

function formatJoinRequestSummary(result, action) {
  const verb = action === 'approve' ? 'approved' : 'rejected';
  if (!result.requested) return `📭 No pending requests to ${verb}.`;
  const lines = [`${action === 'approve' ? '✅' : '🛑'} *Join requests ${verb}*`, `✅ Completed: ${result.succeeded}/${result.requested}`];
  if (result.failed) lines.push(`❌ Failed: ${result.failed}`);
  for (const error of (result.errors || []).slice(0, 2)) lines.push(`ℹ️ ${error}`);
  if (result.failed && !result.errors?.length) lines.push('ℹ️ Some request IDs may have expired or changed. Refresh the pending list and try again.');
  return lines.join('\n');
}

module.exports = { requestJid, findPendingRequest, applyJoinRequestAction, formatJoinRequestSummary };
