// ============================================================
//   helper/listeners.js  – ALL event listeners
//   antidelete, antilink, anticall, antimedia,
//   welcome/goodbye, group participant events
// ============================================================
'use strict';

const path = require('path');
const fs = require('fs');
const axios = require('axios');
const settings = require('../settings');
const { readJSON, writeJSON, ensureDir } = require('./utils');
const { normNum, getGroupAdminInfo } = require('./groupAdmin');
const { retrieveMessage, getWaSettings, setWaSetting } = require('./function');

const AUTO_REACT_EMOJIS = ['❤️', '🔥', '😂', '😍', '👏', '💯', '✨', '👍', '🤍', '😮', '🥳', '🙌'];
const { logInfo, logError, logWarn } = require('./logger');
const { generateWelcomeCard } = require('./welcomeImg');

const DB = (...f) => path.resolve(__dirname, '../database', ...f);
ensureDir(path.resolve(__dirname, '../database'));

// ── DB helpers ────────────────────────────────────────────────
function getDB(file) { return readJSON(DB(file), {}); }
function setDB(file, data) { writeJSON(DB(file), data); }
function getGroupFlag(file, jid)         { return !!(getDB(file)[jid]); }
function setGroupFlag(file, jid, val)    { const d = getDB(file); d[jid] = val; setDB(file, d); }

// ── Download media from baileys ───────────────────────────────
async function dlMedia(msgObj, keyObj) {
  const baileys = require('blacklord-baileys');
  const logger = { info(){}, error(){}, warn(){}, debug(){}, child(){ return this; } };
  try {
    return await baileys.downloadMediaMessage(
      { message: msgObj, key: keyObj }, 'buffer', {}, { logger }
    );
  } catch (firstError) {
    const type = Object.keys(msgObj || {}).find(k => /Message$/.test(k));
    const contentType = type ? type.replace(/Message$/, '').toLowerCase() : null;
    if (!contentType || typeof baileys.downloadContentFromMessage !== 'function') throw firstError;
    const stream = await baileys.downloadContentFromMessage(msgObj[type], contentType);
    const chunks = [];
    for await (const chunk of stream) chunks.push(Buffer.from(chunk));
    return Buffer.concat(chunks);
  }
}

// ── Fetch image as buffer from URL ───────────────────────────
async function fetchImageBuffer(url) {
  if (!url) return null;
  try {
    const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 8000 });
    return Buffer.from(res.data);
  } catch { return null; }
}

// ── Anti-delete adapter ───────────────────────────────────────
// The implementation is per socket, opt-in, and private-DM only.
const antiDelete = require('./antidelete');
const saveAntiDeleteMessage = (sock, message) => antiDelete.saveMessage(sock, message);
const handleAntiDelete = (sock, update) => antiDelete.handleDelete(sock, update);
const handleAntiDeleteUpdate = (sock, updates) => antiDelete.handleDeleteUpdate(sock, updates);

function unwrapMessage(message) {
  let value = message || {};
  for (const wrapper of ['ephemeralMessage', 'viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension']) {
    if (value[wrapper]?.message) value = value[wrapper].message;
  }
  return value;
}

function describeMessage(message) {
  const value = unwrapMessage(message);
  const type = Object.keys(value).find(k => !['messageContextInfo', 'senderKeyDistributionMessage', 'protocolMessage'].includes(k));
  if (!type) return '[message content unavailable]';
  const data = value[type] || {};
  const text = value.conversation || data.text || data.caption || data.contentText || data.selectedDisplayText;
  return text ? `${type}: ${String(text)}` : `[${type}]`;
}

async function handleAntiEditUpdate(sock, updates) {
  const waNum = sock.__waNum || normNum(sock.user?.id || '');
  const c = getWaSettings(waNum);
  if (!c.antiedit) return;
  const pairedNumber = normNum(waNum || sock.user?.id || '');
  if (!/^\d{7,15}$/.test(pairedNumber)) return;
  const pairedPrivateJid = `${pairedNumber}@s.whatsapp.net`;
  const list = Array.isArray(updates) ? updates : [updates];
  for (const entry of list) {
    const update = entry?.update || {};
    const protocol = update.message?.protocolMessage || update.protocolMessage || {};
    const editedMessage = protocol.editedMessage || update.editedMessage || update.message?.editedMessage;
    const type = protocol.type ?? update.message?.protocolMessage?.type;
    const isEdit = !!editedMessage || Number(type) === 14 || String(type).toUpperCase() === 'MESSAGE_EDIT';
    if (!isEdit || !entry?.key || entry.key.fromMe) continue;

    // Baileys variants carry the original key in protocol.key, or provide only
    // the update key. Keep the DM JID as a fallback when protocol.key is partial.
    const suppliedKey = protocol.key || update.key || {};
    const originalKey = {
      ...entry.key,
      ...suppliedKey,
      remoteJid: suppliedKey.remoteJid || entry.key.remoteJid,
      id: suppliedKey.id || entry.key.id,
    };
    if (!originalKey.remoteJid || !originalKey.id) continue;
    const scope = sock.__waNum || waNum || 'default';
    const original = retrieveMessage(originalKey.remoteJid, originalKey.id, scope)
      || retrieveMessage(entry.key.remoteJid, entry.key.id, scope);
    const sender = original?.key?.participant || entry.key.participant || entry.key.participantAlt || entry.key.remoteJid;
    const number = normNum(sender);
    const name = original?.pushName || entry.pushName || number || 'Unknown';
    const before = describeMessage(original?.message);
    // The pinned Baileys version emits update.message.editedMessage.message.
    // Other compatible builds may emit the edited content directly.
    const editedContent = editedMessage?.message || editedMessage;
    const after = describeMessage(editedContent);
    const chatJid = originalKey.remoteJid;
    const chat = chatJid.endsWith('@g.us') ? `Group: ${chatJid}` : 'Direct chat';
    if (!chatJid) continue;
    try {
      await sock.sendMessage(pairedPrivateJid, {
        text: `✏️ *Anti-edit alert*\n👤 Edited by: ${name}${number ? ` · +${number}` : ''}\n📍 Original chat: ${chat}\n\n▫️ *Before*\n${before}\n\n▫️ *After*\n${after}`,
      });
    } catch (e) { logWarn('AntiEdit', e.message); }
  }
}


async function checkAntiContact(sock, m) {
  const groupJid = m?.key?.remoteJid;
  if (!groupJid?.endsWith('@g.us') || !m.message || m.key.fromMe || !getGroupFlag('anticontact.json', groupJid)) return;
  const inner = m.message.ephemeralMessage?.message || m.message;
  if (!inner.contactMessage && !inner.contactsArrayMessage) return;
  const senderNum = normNum(m.key.participant || '');
  try { const { admins } = await getGroupAdminInfo(sock, groupJid); if (admins.has(senderNum)) return; } catch { return; }
  try { await sock.sendMessage(groupJid, { delete: m.key }); } catch {}
}

// Forward and short-burst spam checks use the group flag files toggled by
// .antiforward and .antispam. Anti-spam deliberately limits only clear bursts.
const spamBursts = new Map();
async function checkAntiForward(sock, m) {
  const groupJid = m?.key?.remoteJid;
  if (!groupJid?.endsWith('@g.us') || !m.message || m.key.fromMe || !getGroupFlag('antiforward.json', groupJid)) return;
  const contexts = [];
  const walk = (value, depth = 0) => {
    if (!value || typeof value !== 'object' || depth > 8) return;
    if (value.contextInfo) contexts.push(value.contextInfo);
    for (const child of Object.values(value)) walk(child, depth + 1);
  };
  walk(m.message);
  const forwarded = contexts.some(ctx => ctx.isForwarded === true || Number(ctx.forwardingScore) > 0);
  if (!forwarded) return;
  const senderNum = normNum(m.key.participant || '');
  try { const { admins } = await getGroupAdminInfo(sock, groupJid); if (admins.has(senderNum)) return; } catch { return; }
  try { await sock.sendMessage(groupJid, { delete: m.key }); } catch {}
}

async function checkAntiSpam(sock, m) {
  const groupJid = m?.key?.remoteJid;
  if (!groupJid?.endsWith('@g.us') || !m.message || m.key.fromMe || !getGroupFlag('antispam.json', groupJid)) return;
  const sender = normNum(m.key.participant || '');
  if (!sender) return;
  try { const { admins } = await getGroupAdminInfo(sock, groupJid); if (admins.has(sender)) return; } catch { return; }
  const now = Date.now(), key = `${groupJid}:${sender}`;
  const hits = (spamBursts.get(key) || []).filter(t => now - t < 6000);
  hits.push(now); spamBursts.set(key, hits);
  if (hits.length < 6) return;
  spamBursts.delete(key);
  try { await sock.sendMessage(groupJid, { delete: m.key }); } catch {}
}

async function checkAntiBug(sock, m) {
  const groupJid = m?.key?.remoteJid;
  if (!groupJid?.endsWith('@g.us') || !m.message || m.key.fromMe || !getGroupFlag('antibug.json', groupJid)) return;
  const raw = JSON.stringify(m.message);
  if (Buffer.byteLength(raw, 'utf8') < 48000) return;
  const senderNum = normNum(m.key.participant || '');
  try { const { admins } = await getGroupAdminInfo(sock, groupJid); if (admins.has(senderNum)) return; } catch { return; }
  try { await sock.sendMessage(groupJid, { delete: m.key }); } catch {}
  logWarn('AntiBug', `Removed oversized message from ${senderNum} in ${groupJid}.`);
}

async function checkAntiForeign(sock, m) {
  const groupJid = m?.key?.remoteJid;
  if (!groupJid?.endsWith('@g.us') || !m.message || m.key.fromMe) return;
  const allowedPrefix = getDB('antiforeign.json')[groupJid];
  if (!allowedPrefix || typeof allowedPrefix !== 'string') return;
  const senderNum = normNum(m.key.participant || '');
  if (!senderNum || senderNum.startsWith(allowedPrefix)) return;
  try { const { admins } = await getGroupAdminInfo(sock, groupJid); if (admins.has(senderNum)) return; } catch { return; }
  try { await sock.sendMessage(groupJid, { delete: m.key }); } catch {}
  try { await sock.sendMessage(groupJid, { text: `🚫 @${senderNum}, only +${allowedPrefix} numbers are allowed.`, mentions: [m.key.participant] }); } catch {}
}


async function handleAutoSaveMedia(sock, m) {
  if (!m?.message || m.key?.fromMe || m.key?.remoteJid === 'status@broadcast') return;
  const c = getWaSettings(sock.__waNum || '');
  if (!c.autoMedia) return;
  const message = m.message.ephemeralMessage?.message || m.message;
  const mediaKey = ['imageMessage','videoMessage','audioMessage','documentMessage','stickerMessage'].find(k => message[k]);
  if (!mediaKey) return;
  try {
    const dir = path.resolve(__dirname, '../database/media-cache', String(sock.__waNum || 'default').replace(/[^0-9A-Za-z_-]/g, ''));
    fs.mkdirSync(dir, { recursive: true });
    const ext = { imageMessage:'jpg', videoMessage:'mp4', audioMessage:'ogg', documentMessage:'bin', stickerMessage:'webp' }[mediaKey];
    const file = path.join(dir, `${Date.now()}-${String(m.key.id || '').replace(/[^0-9A-Za-z_-]/g, '')}.${ext}`);
    const buf = await dlMedia({ [mediaKey]: message[mediaKey] }, m.key);
    if (buf?.length && buf.length <= 20 * 1024 * 1024) fs.writeFileSync(file, buf);
  } catch (e) { logWarn('AutoMedia', e.message); }
}

async function handleAutoDownloadStatus(sock, m) {
  if (!m?.message || m.key?.fromMe || m.key?.remoteJid !== 'status@broadcast') return;
  const c = getWaSettings(sock.__waNum || '');
  if (!c.autoDownloadStatus) return;
  try {
    const dir = path.resolve(__dirname, '../database/status-cache', String(sock.__waNum || 'default').replace(/[^0-9A-Za-z_-]/g, ''));
    fs.mkdirSync(dir, { recursive: true });
    const message = m.message.ephemeralMessage?.message || m.message;
    const mediaKey = ['imageMessage','videoMessage','audioMessage'].find(k => message[k]);
    if (mediaKey) {
      const ext = { imageMessage:'jpg', videoMessage:'mp4', audioMessage:'ogg' }[mediaKey];
      const buf = await dlMedia({ [mediaKey]: message[mediaKey] }, m.key);
      if (buf?.length && buf.length <= 20 * 1024 * 1024) fs.writeFileSync(path.join(dir, `${Date.now()}-${String(m.key.id || '').replace(/[^0-9A-Za-z_-]/g, '')}.${ext}`), buf);
    } else {
      const text = message.conversation || message.extendedTextMessage?.text || '';
      if (text) fs.writeFileSync(path.join(dir, `${Date.now()}-${String(m.key.id || '').replace(/[^0-9A-Za-z_-]/g, '')}.txt`), text);
    }
  } catch (e) { logWarn('AutoDownloadStatus', e.message); }
}

async function handleAutoPackSticker(sock, m) {
  if (!m?.message || m.key?.fromMe || m.key?.remoteJid === 'status@broadcast') return;
  const c = getWaSettings(sock.__waNum || '');
  if (!c.autoPackSticker) return;
  const message = m.message.ephemeralMessage?.message || m.message;
  if (!message.imageMessage || message.imageMessage.viewOnce) return;
  try {
    const stickerLib = require('./sticker');
    const buf = await dlMedia({ imageMessage: message.imageMessage }, m.key);
    const sticker = await stickerLib.makeSticker(buf, { pack: c.stickerPackName || 'TALKLESS', author: c.stickerPackAuthor || 'TALKLESS' });
    await sock.sendMessage(m.key.remoteJid, { sticker }, { quoted: m });
  } catch (e) { logWarn('AutoPackSticker', e.message); }
}

async function handleAutoReact(sock, m) {
  const waNum = sock.__waNum || normNum(sock.user?.id || '');
  const c = getWaSettings(waNum);
  if (!c.autoReact || !m?.message || m.key?.fromMe || m.key?.remoteJid !== 'status@broadcast') return;
  const statusOwner = m.key.participant || m.key.participantPn || m.key.participantAlt;
  if (!statusOwner) { logWarn('AutoReact', 'Status message has no participant JID; skipped.'); return; }
  const emoji = c.autoReactEmoji || AUTO_REACT_EMOJIS[Math.floor(Math.random() * AUTO_REACT_EMOJIS.length)];
  try {
    await sock.sendMessage('status@broadcast', { react: { text: emoji, key: m.key } }, { statusJidList: [statusOwner] });
  } catch (e) { logWarn('AutoReact', e.message); }
}

// Mark every received WhatsApp status as viewed for this paired account.
// This socket only emits the receipt; nothing is routed to the status sender,
// a group, or another paired session.
async function handleAutoViewStatus(sock, m) {
  const waNum = sock.__waNum || normNum(sock.user?.id || '');
  const c = getWaSettings(waNum);
  if (c.autoViewStatus === false || !m?.key || m.key.fromMe || m.key.remoteJid !== 'status@broadcast') return;
  try {
    await sock.readMessages([m.key]);
  } catch (e) { logWarn('AutoViewStatus', e.message); }
}

// ════════════════════════════════════════════════════════════
//   ANTILINK  –  full listener
// ════════════════════════════════════════════════════════════
const LINK_RE = /https?:\/\/|chat\.whatsapp\.com|t\.me\/|discord\.gg\/|bit\.ly\/|tinyurl\.com\//i;

async function checkAntilink(sock, m) {
  if (!m.key.remoteJid.endsWith('@g.us')) return;
  if (!getGroupFlag('antilink.json', m.key.remoteJid)) return;

  const body = [
    m.message?.conversation,
    m.message?.extendedTextMessage?.text,
    m.message?.imageMessage?.caption,
    m.message?.videoMessage?.caption,
  ].filter(Boolean).join(' ');

  if (!LINK_RE.test(body)) return;

  // Admins exempt
  const senderNum = normNum(m.key.participant || m.key.remoteJid);
  const { admins } = await getGroupAdminInfo(sock, m.key.remoteJid);
  if (admins.has(senderNum)) return;

  try { await sock.sendMessage(m.key.remoteJid, { delete: m.key }); } catch {}
  try {
    await sock.sendMessage(m.key.remoteJid, {
      text: `⚠️ @${senderNum} Links are not allowed here! Message deleted.`,
      mentions: [m.key.participant || m.key.remoteJid],
    });
  } catch {}
}

// ════════════════════════════════════════════════════════════
//   ANTIMEDIA  –  delete media from non-admins
// ════════════════════════════════════════════════════════════
async function checkAntiMedia(sock, m) {
  if (!m.key.remoteJid.endsWith('@g.us')) return;

  const types = getDB('anti-media-types.json')[m.key.remoteJid] || {};
  const mediaKinds = [];
  if (m.message?.imageMessage) mediaKinds.push('image');
  if (m.message?.videoMessage) mediaKinds.push(m.message.videoMessage.gifPlayback ? 'gif' : 'video');
  if (m.message?.audioMessage) mediaKinds.push('audio');
  if (m.message?.stickerMessage) mediaKinds.push('sticker');
  if (m.message?.documentMessage) mediaKinds.push('document');
  const inner = m.message?.ephemeralMessage?.message || m.message;
  const hasViewOnce = Object.entries(inner || {}).some(([key, value]) => /viewOnceMessage/i.test(key) || (value && typeof value === 'object' && value.viewOnce === true));
  const shouldBlockViewOnce = hasViewOnce && getGroupFlag('antiviewonce.json', m.key.remoteJid);
  if (!shouldBlockViewOnce && (!mediaKinds.length || (!mediaKinds.some(kind => types[kind]) && !getGroupFlag('antimedia.json', m.key.remoteJid)))) return;

  const senderNum = normNum(m.key.participant || m.key.remoteJid);
  const { admins } = await getGroupAdminInfo(sock, m.key.remoteJid);
  if (admins.has(senderNum)) return;

  try { await sock.sendMessage(m.key.remoteJid, { delete: m.key }); } catch {}
  try {
    await sock.sendMessage(m.key.remoteJid, {
      text: `🚫 @${senderNum} Media not allowed here.`,
      mentions: [m.key.participant || m.key.remoteJid],
    });
  } catch {}
}

// Delete explicit whole-group mentions and obvious mass-tag messages. The
// existing .antimention on/off flag is stored per group.
async function checkAntiGroupMention(sock, m) {
  const groupJid = m?.key?.remoteJid;
  if (!groupJid?.endsWith('@g.us') || !m.message || m.key.fromMe) return;
  const antiMentionEnabled = getGroupFlag('antimention.json', groupJid);

  const contexts = [];
  const walk = (value, depth = 0) => {
    if (!value || typeof value !== 'object' || depth > 8) return;
    if (value.contextInfo) contexts.push(value.contextInfo);
    for (const child of Object.values(value)) walk(child, depth + 1);
  };
  walk(m.message);

  const explicitGroupMention = contexts.some(ctx =>
    (Array.isArray(ctx.groupMentions) && ctx.groupMentions.some(entry =>
      [entry?.groupJid, entry?.jid, entry?.groupId].includes(groupJid))) ||
    (Array.isArray(ctx.mentionedJid) && ctx.mentionedJid.includes(groupJid))
  );
  const mentionJids = [...new Set(contexts.flatMap(ctx => Array.isArray(ctx.mentionedJid) ? ctx.mentionedJid : []))];
  const body = [m.message.conversation, m.message.extendedTextMessage?.text,
    m.message.imageMessage?.caption, m.message.videoMessage?.caption,
    m.message.documentMessage?.caption].filter(Boolean).join(' ');
  let massMention = /(?:^|\s)@(everyone|all)\b/i.test(body);

  if (!explicitGroupMention && !massMention && mentionJids.length >= 3) {
    try {
      const metadata = await sock.groupMetadata(groupJid);
      const memberCount = metadata?.participants?.length || 0;
      massMention = memberCount > 0 && mentionJids.length >= Math.max(3, Math.ceil(memberCount * 0.5));
    } catch {}
  }
  const mentionFlags = getDB('antitag.json')[groupJid] || false;
  const adminTagFlag = getDB('antitagadmins.json')[groupJid] || false;
  let targetedAdmin = false;
  if (adminTagFlag && mentionJids.length) {
    try {
      const meta = await sock.groupMetadata(groupJid);
      const adminNums = new Set((meta.participants || []).filter(p => p.admin).map(p => normNum(p.id || p.jid)).filter(Boolean));
      targetedAdmin = mentionJids.some(j => adminNums.has(normNum(j)));
    } catch {}
  }
  if (!(antiMentionEnabled && (explicitGroupMention || massMention)) && !(mentionFlags && mentionJids.length) && !targetedAdmin) return;

  const senderNum = normNum(m.key.participant || m.key.remoteJid);
  let admins;
  try {
    ({ admins } = await getGroupAdminInfo(sock, groupJid));
  } catch { return; }
  if (admins?.has(senderNum)) return;

  try { await sock.sendMessage(groupJid, { delete: m.key }); }
  catch (e) { logWarn('AntiMention', `Could not delete group mention in ${groupJid}: ${e.message}`); }
}

// ════════════════════════════════════════════════════════════
//   ANTICALL
// ════════════════════════════════════════════════════════════
async function handleAntiCall(sock, call) {
  const c = getWaSettings(sock.__waNum || '');
  if (!c.anticall) return;
  for (const cCall of call) {
    if (cCall.status === 'offer') {
      try {
        await sock.rejectCall(cCall.id, cCall.from);
        await sock.sendMessage(cCall.from, { text: `❌ Sorry, I don't accept calls. Please text instead.` });
      } catch {}
    }
  }
}

// ════════════════════════════════════════════════════════════
//   WELCOME / GOODBYE  –  with generated image
// ════════════════════════════════════════════════════════════
// Track sent welcomes per session to avoid spam: jid+participant
const welcomeSent = new Set();

async function handleGroupParticipantsUpdate(sock, update) {
  const groupJid = update?.id;
  const action = String(update?.action || '').toLowerCase();
  const participants = (Array.isArray(update?.participants) ? update.participants : [])
    .map(p => typeof p === 'string' ? p : (p?.id || p?.jid || p?.phoneNumber || ''))
    .filter(Boolean);
  if (!groupJid?.endsWith('@g.us') || !participants.length) return;

  // Reverse admin role changes when the corresponding owner-configured guard is active.
  // The socket must already have permission to update group participants.
  if (groupJid && Array.isArray(participants) && ['promote', 'demote'].includes(action)) {
    const flagFile = action === 'promote' ? 'antipromote.json' : 'antidemote.json';
    if (getGroupFlag(flagFile, groupJid)) {
      const reverseAction = action === 'promote' ? 'demote' : 'promote';
      for (const participant of participants) {
        try { await sock.groupParticipantsUpdate(groupJid, [participant], reverseAction); }
        catch (e) { logWarn('AntiAdminChange', `Could not reverse ${action} for ${participant}: ${e.message}`); }
      }
      return;
    }
  }

  // WELCOME
  if (['add', 'join'].includes(action) && getGroupFlag('welcome.json', groupJid)) {
    let groupPpUrl = null;
    try { groupPpUrl = await sock.profilePictureUrl(groupJid, 'image'); } catch {}

    let groupName = groupJid;
    try { const meta = await sock.groupMetadata(groupJid); groupName = meta.subject; } catch {}

    for (const participant of participants) {
      const dedupeKey = `${groupJid}:${participant}`;
      if (welcomeSent.has(dedupeKey)) continue;
      welcomeSent.add(dedupeKey);
      setTimeout(() => welcomeSent.delete(dedupeKey), 30000);

      const num  = normNum(participant);
      let ppUrl  = null;
      try { ppUrl = await sock.profilePictureUrl(participant, 'image'); } catch {}

      let pushName = num;
      try {
        const info = await sock.onWhatsApp(participant);
        if (info?.[0]?.name) pushName = info[0].name;
      } catch {}

      const savedWelcome = getDB('welcomemsgs.json')[groupJid];
      const welcomeTemplate = typeof savedWelcome === 'string' && savedWelcome.trim()
        ? savedWelcome
        : `👋 *Welcome @${num}!*\n\nGlad to have you in *${groupName}*.\nPlease read the group rules and enjoy your stay! 🎉`;
      const caption = welcomeTemplate
        .replace(/\{name\}/gi, pushName)
        .replace(/\{group\}/gi, groupName)
        .replace(/\{number\}/gi, `@${num}`);

      // A missing image dependency or unavailable profile picture must never
      // prevent the text welcome from being sent.
      let cardBuf = null;
      try {
        cardBuf = await generateWelcomeCard({
          userName: pushName,
          groupName,
          userPpUrl: ppUrl,
          groupPpUrl,
        });
      } catch (e) {
        logWarn('Welcome', `Card generation failed; using text fallback: ${e.message}`);
      }

      try {
        if (cardBuf) {
          await sock.sendMessage(groupJid, {
            image:    cardBuf,
            caption,
            mentions: [participant],
          });
        } else if (ppUrl) {
          // Fallback: fetch user profile pic and send as image (no canvas)
          try {
            const imgBuf = await fetchImageBuffer(ppUrl);
            if (imgBuf) {
              await sock.sendMessage(groupJid, {
                image:    imgBuf,
                caption,
                mentions: [participant],
              });
            } else {
              throw new Error('img fetch failed');
            }
          } catch {
            await sock.sendMessage(groupJid, {
              text:     caption,
              mentions: [participant],
            });
          }
        } else {
          // No profile pic at all – plain text welcome
          await sock.sendMessage(groupJid, {
            text:     caption,
            mentions: [participant],
          });
        }
      } catch (e) {
        logError('Welcome', e.message);
        try { await sock.sendMessage(groupJid, { text: caption, mentions: [participant] }); }
        catch (fallbackError) { logError('Welcome', `Text fallback failed: ${fallbackError.message}`); }
      }
    }
  }

  // GOODBYE
  if (['remove', 'leave'].includes(action) && getGroupFlag('goodbye.json', groupJid)) {
    let groupName = groupJid;
    try { const meta = await sock.groupMetadata(groupJid); groupName = meta.subject; } catch {}

    for (const participant of participants) {
      const num = normNum(participant);
      const savedGoodbye = getDB('goodbyemsgs.json')[groupJid];
      const goodbyeTemplate = typeof savedGoodbye === 'string' &&
        savedGoodbye.trim() && savedGoodbye.trim().toLowerCase() !== 'name'
        ? savedGoodbye
        : `👋 *Goodbye @${num}!*\nWe'll miss you in *${groupName}*. Take care! 💜`;
      let goodbyeText = goodbyeTemplate
        .replace(/\{name\}/gi, `@${num}`)
        .replace(/\{group\}/gi, groupName)
        .replace(/\{number\}/gi, `@${num}`);
      if (!goodbyeText.includes(`@${num}`)) goodbyeText += `\n@${num}`;
      try {
        await sock.sendMessage(groupJid, {
          text:     goodbyeText,
          mentions: [participant],
        });
      } catch (e) { logWarn('Goodbye', `Could not send goodbye in ${groupJid}: ${e.message}`); }
    }
  }
}

// ── Exports for flag get/set (used by case.js commands) ──────
module.exports = {
  // listeners
  saveAntiDeleteMessage,
  handleAntiDelete,
  handleAntiDeleteUpdate,
  handleAntiEditUpdate,
  handleAutoReact,
  handleAutoSaveMedia,
  handleAutoDownloadStatus,
  handleAutoPackSticker,
  handleAutoViewStatus,
  checkAntilink,
  checkAntiMedia,
  checkAntiGroupMention,
  checkAntiContact,
  checkAntiForward,
  checkAntiSpam,
  checkAntiBug,
  checkAntiForeign,
  handleAntiCall,
  handleGroupParticipantsUpdate,
  // flag helpers
  getGroupFlag,
  setGroupFlag,
};
