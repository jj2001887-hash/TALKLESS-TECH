'use strict';

const fs = require('fs');
const path = require('path');

// Use dotenv when installed. The small fallback keeps deployments on panels
// that skip npm install from failing before the bot can read panel variables.
module.exports = function loadEnv() {
  try {
    require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });
    return;
  } catch (error) {
    if (error?.code !== 'MODULE_NOT_FOUND' || !String(error.message).includes('dotenv')) throw error;
  }

  const envFile = path.resolve(__dirname, '..', '.env');
  let source;
  try { source = fs.readFileSync(envFile, 'utf8'); }
  catch (error) { if (error.code === 'ENOENT') return; throw error; }

  for (const rawLine of source.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const match = line.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if (!match) continue;
    const [, key] = match;
    if (Object.prototype.hasOwnProperty.call(process.env, key)) continue;
    let value = match[2].trim();
    const quote = value[0];
    if ((quote === '"' || quote === "'") && value.endsWith(quote)) {
      value = value.slice(1, -1);
      if (quote === '"') value = value.replace(/\\n/g, '\n').replace(/\\r/g, '\r');
    } else {
      value = value.replace(/\s+#.*$/, '').trim();
    }
    process.env[key] = value;
  }
};
