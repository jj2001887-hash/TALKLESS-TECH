// imagegen.js – Name / text image creation (rendered locally, no outside service)
// Whatever name or text the user types is drawn on the image exactly as typed.
'use strict';
const path  = require('path');
const sharp = require('sharp');

// ---------------------------------------------------------------- fonts
// Fonts ship with the bot (media/fonts) so the text always renders, even on
// hosts that have no system fonts installed.
const FONT_DIR = path.join(__dirname, 'media', 'fonts');
const FONTS = {
  latin:  { family: 'Poppins Bold',     file: path.join(FONT_DIR, 'Poppins-Bold.ttf') },
  global: { family: 'DejaVu Sans Bold', file: path.join(FONT_DIR, 'DejaVuSans-Bold.ttf') }, // Arabic, Cyrillic, Greek...
};
const needsGlobalFont = s => /[^\u0000-\u024F\u1E00-\u1EFF\u2000-\u206F\u20A0-\u20CF]/.test(s);
const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const rnd = (a, b) => a + Math.random() * (b - a);
const pick = arr => arr[Math.floor(Math.random() * arr.length)];

async function renderText(text, color, boxW, boxH, fontKey) {
  const f = FONTS[fontKey];
  return sharp({
    text: {
      text: `<span foreground="${color}">${esc(text)}</span>`,
      font: f.family, fontfile: f.file,
      width: Math.round(boxW), height: Math.round(boxH),
      align: 'center', rgba: true,
    },
  }).png().toBuffer({ resolveWithObject: true });
}

// ---------------------------------------------------------------- backgrounds
const svg = (W, H, inner) =>
  Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">${inner}</svg>`);
const lin = (id, c1, c2, x2 = 1, y2 = 1) =>
  `<linearGradient id="${id}" x1="0" y1="0" x2="${x2}" y2="${y2}"><stop offset="0" stop-color="${c1}"/><stop offset="1" stop-color="${c2}"/></linearGradient>`;
const rad = (id, c1, c2) =>
  `<radialGradient id="${id}" cx="50%" cy="50%" r="75%"><stop offset="0" stop-color="${c1}"/><stop offset="1" stop-color="${c2}"/></radialGradient>`;
const rect = fill => `<rect width="100%" height="100%" fill="${fill}"/>`;

const PALETTES = [
  ['#667eea', '#764ba2'], ['#f5576c', '#8e2de2'], ['#0072ff', '#00c6ff'], ['#11998e', '#38ef7d'],
  ['#fc4a1a', '#f7b733'], ['#8e2de2', '#4a00e0'], ['#ee0979', '#ff6a00'], ['#1e3c72', '#2a5298'],
];
const FLAT = ['#e63946', '#2a9d8f', '#e76f51', '#3a86ff', '#8338ec', '#fb5607', '#06a77d', '#d90368'];

function bokeh(W, H, n, maxR) {
  let s = '';
  for (let i = 0; i < n; i++) {
    s += `<circle cx="${rnd(0, W).toFixed(0)}" cy="${rnd(0, H).toFixed(0)}" r="${rnd(maxR * 0.25, maxR).toFixed(0)}" fill="#fff" fill-opacity="${rnd(0.04, 0.14).toFixed(2)}"/>`;
  }
  return s;
}
function stars(W, H, n) {
  let s = '';
  for (let i = 0; i < n; i++) {
    s += `<circle cx="${rnd(0, W).toFixed(0)}" cy="${rnd(0, H).toFixed(0)}" r="${rnd(1, 3.2).toFixed(1)}" fill="#fff" fill-opacity="${rnd(0.4, 1).toFixed(2)}"/>`;
  }
  return s;
}

// ---------------------------------------------------------------- styles
// Each style = { label, bg(W,H), draw(c) } where draw returns a list of layers.
// c gives: W, H, text, t(color) -> text layer, put(layer,dx,dy), glow(color,sigma,dx,dy), outline(color,r,steps)
const STYLES = {
  gradient: {
    label: 'Name Art',
    bg: (W, H) => { const p = pick(PALETTES); return svg(W, H, `<defs>${lin('g', p[0], p[1])}</defs>${rect('url(#g)')}${bokeh(W, H, 9, Math.min(W, H) * 0.18)}`); },
    draw: async c => [await c.glow('#000000', 10, 6, 10), await c.glow('#000000', 4, 3, 5), c.put(await c.t('#ffffff'))],
  },
  flat: {
    label: 'Turbo',
    bg: (W, H) => { const col = pick(FLAT); return svg(W, H, `${rect(col)}<polygon points="0,${H} ${W},${H * 0.35} ${W},${H}" fill="#000" fill-opacity="0.16"/>`); },
    draw: async c => [c.put(await c.t('#000000'), 9, 9), c.put(await c.t('#ffffff'))],
  },
  gold: {
    label: 'Gold',
    bg: (W, H) => svg(W, H, `<defs>${rad('r', '#3a3a3a', '#070707')}</defs>${rect('url(#r)')}<rect x="28" y="28" width="${W - 56}" height="${H - 56}" fill="none" stroke="#d4af37" stroke-width="4"/><rect x="44" y="44" width="${W - 88}" height="${H - 88}" fill="none" stroke="#d4af37" stroke-opacity="0.5" stroke-width="2"/>`),
    draw: async c => [await c.glow('#000000', 8, 5, 8), c.put(await c.t('#7a5c00'), 3, 3), c.put(await c.t('#f4d03f')), c.put(await c.t('#fff3b0'), -2, -2, 0.55)],
  },
  anime: {
    label: 'Anime',
    bg: (W, H) => svg(W, H, `<defs>${lin('g', '#ff9ecd', '#6f9bff', 0, 1)}</defs>${rect('url(#g)')}<circle cx="${W * 0.75}" cy="${H * 0.2}" r="${Math.min(W, H) * 0.16}" fill="#fff" fill-opacity="0.35"/>${stars(W, H, 40)}`),
    draw: async c => [...await c.outline('#ff2d85', 9, 14), c.put(await c.t('#ffffff'))],
  },
  cartoon: {
    label: 'Cartoon',
    bg: (W, H) => svg(W, H, `<defs><pattern id="d" width="46" height="46" patternUnits="userSpaceOnUse"><circle cx="12" cy="12" r="7" fill="#ffb703"/></pattern></defs>${rect('#ffd93d')}${rect('url(#d)')}`),
    draw: async c => [c.put(await c.t('#000000'), 11, 11), ...await c.outline('#000000', 9, 14), c.put(await c.t('#ffffff'))],
  },
  '3d': {
    label: '3D',
    bg: (W, H) => svg(W, H, `<defs>${lin('g', '#141e30', '#35577d')}</defs>${rect('url(#g)')}`),
    draw: async c => {
      const out = [await c.glow('#000000', 12, 16, 22)];
      for (let i = 20; i >= 1; i--) out.push(c.put(await c.t(i > 10 ? '#12406e' : '#1b5f9e'), i, i));
      out.push(c.put(await c.t('#7fe3ff')));
      return out;
    },
  },
  cyberpunk: {
    label: 'Cyberpunk',
    bg: (W, H) => svg(W, H, `<defs>${lin('g', '#0b0221', '#2a0a54', 0, 1)}<pattern id="p" width="60" height="60" patternUnits="userSpaceOnUse"><path d="M60 0H0V60" fill="none" stroke="#ff00c8" stroke-opacity="0.22" stroke-width="2"/></pattern></defs>${rect('url(#g)')}${rect('url(#p)')}`),
    draw: async c => [await c.glow('#ff00c8', 16, 0, 0), await c.glow('#00f0ff', 10, 0, 0), c.put(await c.t('#ff00c8'), 5, 5), c.put(await c.t('#00f0ff'))],
  },
  fantasy: {
    label: 'Fantasy',
    bg: (W, H) => svg(W, H, `<defs>${rad('r', '#3b2290', '#0a0428')}</defs>${rect('url(#r)')}${stars(W, H, 110)}`),
    draw: async c => [await c.glow('#ffb300', 18, 0, 0), ...await c.outline('#2a0f5e', 6, 12), c.put(await c.t('#ffd700')), c.put(await c.t('#fff6c2'), -2, -2, 0.5)],
  },
  sketch: {
    label: 'Sketch',
    bg: (W, H) => { let l = ''; for (let y = 60; y < H; y += 46) l += `<line x1="0" y1="${y}" x2="${W}" y2="${(y + rnd(-2, 2)).toFixed(1)}" stroke="#b9ad96" stroke-opacity="0.35" stroke-width="1.5"/>`; return svg(W, H, `${rect('#f4efe3')}${l}<rect x="26" y="26" width="${W - 52}" height="${H - 52}" fill="none" stroke="#6b6558" stroke-width="3" stroke-dasharray="14 8"/>`); },
    draw: async c => [c.put(await c.t('#8a8478'), 3, 3, 0.8), c.put(await c.t('#5c574c'), -2, 2, 0.8), c.put(await c.t('#2f2c26'))],
  },
  wallpaper: {
    label: 'Wallpaper',
    size: [1344, 768],
    bg: (W, H) => { const p = pick(PALETTES); return svg(W, H, `<defs>${lin('g', p[0], p[1], 1, 0.4)}</defs>${rect('url(#g)')}${bokeh(W, H, 16, H * 0.22)}`); },
    draw: async c => [await c.glow('#000000', 12, 6, 12), c.put(await c.t('#ffffff'))],
  },
  portrait: {
    label: 'Portrait',
    size: [768, 1344],
    bg: (W, H) => { const p = pick(PALETTES); return svg(W, H, `<defs>${lin('g', p[0], p[1], 0.3, 1)}</defs>${rect('url(#g)')}${bokeh(W, H, 14, W * 0.25)}`); },
    draw: async c => [await c.glow('#000000', 12, 6, 12), c.put(await c.t('#ffffff'))],
  },
  pixel: { label: 'Pixel Art', custom: true },
  logo:  { label: 'Logo',      custom: true, size: [1024, 1024] },
};

// command -> style
const CMD_STYLE = {
  imagine: 'gradient', flux: 'gradient', dalle: 'gradient', aiimage: 'gradient', genimg: 'gradient',
  name: 'gradient', namepic: 'gradient',
  turbo: 'flat', sdxl: 'flat',
  realistic: 'gold', animeart: 'anime', cartoonart: 'cartoon', '3d': '3d',
  cyberpunk: 'cyberpunk', fantasy: 'fantasy', pixelart: 'pixel', sketchart: 'sketch',
  logo: 'logo', wallpaper: 'wallpaper', portrait: 'portrait',
};
const IMAGE_CMDS = Object.keys(CMD_STYLE);

// ---------------------------------------------------------------- rendering
const OUTLINE_PAD = 40;

async function renderNameImage(styleKey, text, W, H) {
  const st = STYLES[styleKey] || STYLES.gradient;
  const fontKey = needsGlobalFont(text) ? 'global' : 'latin';
  const boxW = W * 0.84;
  const boxH = H * (H > W ? 0.34 : 0.42);

  if (st.custom) return styleKey === 'pixel'
    ? renderPixel(text, W, H, fontKey)
    : renderLogo(text, W, H, fontKey);

  const cache = new Map();
  const t = async color => {
    if (!cache.has(color)) cache.set(color, await renderText(text, color, boxW, boxH, fontKey));
    return cache.get(color);
  };
  const base = await t('#ffffff');
  const L = Math.round((W - base.info.width) / 2);
  const T = Math.round((H - base.info.height) / 2);

  const c = {
    W, H, text, t,
    put: (layer, dx = 0, dy = 0, opacity = 1) =>
      ({ input: layer.data, left: L + dx, top: T + dy, opacity }),
    glow: async (color, sigma, dx = 0, dy = 0) => {
      const src = await t(color);
      const input = await sharp(src.data)
        .extend({ top: OUTLINE_PAD, bottom: OUTLINE_PAD, left: OUTLINE_PAD, right: OUTLINE_PAD, background: { r: 0, g: 0, b: 0, alpha: 0 } })
        .blur(sigma).png().toBuffer();
      return { input, left: L - OUTLINE_PAD + dx, top: T - OUTLINE_PAD + dy };
    },
    outline: async (color, r, steps) => {
      const src = await t(color);
      const out = [];
      for (let i = 0; i < steps; i++) {
        const a = (i / steps) * Math.PI * 2;
        out.push({ input: src.data, left: L + Math.round(Math.cos(a) * r), top: T + Math.round(Math.sin(a) * r) });
      }
      return out;
    },
  };

  const layers = (await st.draw(c)).flat().map(l => {
    if (l.opacity !== undefined && l.opacity < 1) return fade(l);
    delete l.opacity;
    return l;
  });
  const resolved = await Promise.all(layers);
  return sharp(st.bg(W, H)).composite(resolved).png().toBuffer();
}

// semi-transparent layer (sharp has no per-layer opacity, so scale alpha ourselves)
async function fade(l) {
  const { data, info } = await sharp(l.input).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  for (let i = 3; i < data.length; i += 4) data[i] = Math.round(data[i] * l.opacity);
  const input = await sharp(data, { raw: { width: info.width, height: info.height, channels: 4 } }).png().toBuffer();
  return { input, left: l.left, top: l.top };
}

async function renderPixel(text, W, H, fontKey) {
  const px = text.length > 14 ? 6 : text.length > 8 ? 8 : 12;
  const sw = Math.floor(W / px), sh = Math.floor(H / px);
  const small = async color => {
    const r = await renderText(text, color, sw * 0.86, sh * 0.34, fontKey);
    const w = r.info.width * px, h = r.info.height * px;
    return { data: await sharp(r.data).resize(w, h, { kernel: 'nearest' }).png().toBuffer(), w, h };
  };
  const main = await small('#39ff14');
  const shade = await small('#0a3d0a');
  const left = Math.round((W - main.w) / 2), top = Math.round((H - main.h) / 2);
  let tiles = '';
  for (let y = 0; y < H; y += px * 4) for (let x = 0; x < W; x += px * 4) {
    if (((x / (px * 4)) + (y / (px * 4))) % 2 === 0) tiles += `<rect x="${x}" y="${y}" width="${px * 4}" height="${px * 4}" fill="#ffffff" fill-opacity="0.04"/>`;
  }
  return sharp(svg(W, H, `${rect('#0d1b2a')}${tiles}`))
    .composite([
      { input: shade.data, left: left + px, top: top + px },
      { input: main.data, left, top },
    ]).png().toBuffer();
}

async function renderLogo(text, W, H, fontKey) {
  const words = text.split(/\s+/).filter(Boolean);
  const initials = words.slice(0, 2).map(w => Array.from(w)[0].toUpperCase()).join('');
  const p = pick(PALETTES);
  const r = Math.min(W, H) * 0.2, cx = W / 2, cy = H * 0.36;
  const badge = svg(W, H, `<defs>${lin('g', p[0], p[1])}</defs>${rect('#ffffff')}<circle cx="${cx}" cy="${cy}" r="${r + 14}" fill="none" stroke="url(#g)" stroke-width="6"/><circle cx="${cx}" cy="${cy}" r="${r}" fill="url(#g)"/>`);
  const ini = await renderText(initials, '#ffffff', r * 1.3, r * 1.0, fontKey);
  const nm  = await renderText(text, '#1d1d2b', W * 0.84, H * 0.2, fontKey);
  return sharp(badge).composite([
    { input: ini.data, left: Math.round(cx - ini.info.width / 2), top: Math.round(cy - ini.info.height / 2) },
    { input: nm.data,  left: Math.round((W - nm.info.width) / 2), top: Math.round(H * 0.68 - nm.info.height / 2) },
  ]).png().toBuffer();
}

// ---------------------------------------------------------------- command handler
const STYLE_LIST = ['realistic', 'animeart', 'cartoonart', '3d', 'cyberpunk', 'fantasy', 'pixelart', 'sketchart', 'logo', 'wallpaper', 'portrait', 'turbo'];

async function imageGenHandler(sock, m, cmd, args, helpers) {
  if (!CMD_STYLE[cmd]) return false;
  const { reply, ft, cfg, reaction, getQuoted } = helpers;
  const jid    = m.key.remoteJid;
  const prefix = cfg(sock).prefix || '.';
  const style  = STYLES[CMD_STYLE[cmd]];

  // flags: --wide / --tall / --square, everything else is the text to draw
  let [W, H] = style.size || [1024, 1024];
  const words = [];
  for (const a of (args || [])) {
    const f = String(a).toLowerCase();
    if (f === '--wide')        [W, H] = [1344, 768];
    else if (f === '--tall')   [W, H] = [768, 1344];
    else if (f === '--square') [W, H] = [1024, 1024];
    else words.push(a);
  }
  let text = words.join(' ');

  // replying to a text message uses that text
  if (!text.trim()) {
    try {
      const { qMsg } = getQuoted(m);
      text = qMsg?.conversation || qMsg?.extendedTextMessage?.text || '';
    } catch {}
  }
  text = text.replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 40);

  if (!text) {
    await reply(
      `🎨 *${prefix}${cmd} <name or text>*\n\n` +
      `Example: ${prefix}${cmd} Jennifer\n` +
      `The exact name you type will be written on the image.\n` +
      `Size flags: --wide  --tall  --square\n\n` +
      `Styles: ${STYLE_LIST.map(s => prefix + s).join(' ')}`
    );
    return true;
  }

  reaction('🎨');
  try {
    const buffer = await renderNameImage(CMD_STYLE[cmd], text, W, H);
    await sock.sendMessage(jid, {
      image: buffer,
      caption: ft(`🎨 *${style.label}*\n🔤 ${text}`, sock),
    }, { quoted: m });
    reaction('✅');
  } catch (e) {
    console.error('[imagegen]', e);
    reaction('❌');
    await reply(`❌ Could not create the image (${e.message}). Please try again.`);
  }
  return true;
}

module.exports = { imageGenHandler, IMAGE_CMDS, renderNameImage };
