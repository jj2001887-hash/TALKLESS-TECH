'use strict';


const FANCY_MAP = {
  bold: [0x1d5d4, 0x1d5ed], italic: [0x1d608, 0x1d621], script: [0x1d4d0, 0x1d4e9],
  double: [0x1d538, 0x1d551], mono: [0x1d670, 0x1d689],
};
function stylize(text, style = 'bold') {
  const range = FANCY_MAP[style] || FANCY_MAP.bold;
  return [...text].map(ch => {
    const c = ch.codePointAt(0);
    if (c >= 65 && c <= 90) return String.fromCodePoint(range[0] + c - 65);
    if (c >= 97 && c <= 122) return String.fromCodePoint(range[1] + c - 97);
    return ch;
  }).join('');
}

async function referenceCommandHandler(sock, m, cmd, args, h) {
  const { reply, isOwner, isGroupAdmin } = h;
  const jid = m.key.remoteJid;
  const text = args.join(' ').trim();
  switch (cmd) {
    case 'fancy': {
      if (!text) { await reply('Usage: .fancy <text> [bold|italic|script|double|mono]'); break; }
      const parts = text.split(/\s+/);
      const style = parts.at(-1).toLowerCase();
      const chosen = FANCY_MAP[style] ? style : 'bold';
      const source = FANCY_MAP[style] ? parts.slice(0, -1).join(' ') : text;
      await reply(stylize(source, chosen));
      break;
    }
    case 'checkwa': {
      const number = String(args[0] || '').replace(/\D/g, '');
      if (!number || number.length < 7 || number.length > 15) { await reply('Usage: .checkwa <country-code-and-number> (digits only)'); break; }
      if (typeof sock.onWhatsApp !== 'function') { await reply('This WhatsApp connection does not expose account lookup.'); break; }
      try {
        const result = await sock.onWhatsApp(`${number}@s.whatsapp.net`);
        const found = Array.isArray(result) && result.some(x => x.exists);
        await reply(found ? `✅ +${number} is registered on WhatsApp.` : `❌ +${number} was not found on WhatsApp.`);
      } catch (e) { await reply(`Lookup failed: ${e.message}`); }
      break;
    }
    case 'inviteinfo': {
      const code = (text.match(/(?:chat\.whatsapp\.com\/)?([A-Za-z0-9_-]{18,})/) || [])[1];
      if (!code) { await reply('Usage: .inviteinfo <WhatsApp group invite link>'); break; }
      if (typeof sock.groupGetInviteInfo !== 'function') { await reply('Group invite lookup is not supported by this WhatsApp library version.'); break; }
      try {
        const info = await sock.groupGetInviteInfo(code);
        const parts = [`Group: ${info.subject || info.name || 'Unknown'}`, `Group ID: ${info.id || info.jid || 'unavailable'}`];
        if (info.size != null) parts.push(`Members: ${info.size}`);
        if (info.creation) parts.push(`Created: ${new Date(Number(info.creation) * 1000).toLocaleString()}`);
        await reply(`ℹ️ *Invite information*\n\n${parts.join('\n')}`);
      } catch (e) { await reply(`Could not read invite: ${e.message}`); }
      break;
    }
    case 'delpp': {
      if (!isOwner) { await reply('Owner only.'); break; }
      if (typeof sock.removeProfilePicture !== 'function') { await reply('This WhatsApp library does not support removing the profile picture.'); break; }
      try { await sock.removeProfilePicture(jid); await reply('✅ Profile picture removed.'); }
      catch (e) { await reply(`Could not remove profile picture: ${e.message}`); }
      break;
    }
    case 'vcf': {
      if (!jid.endsWith('@g.us')) { await reply('Use .vcf inside a group to export its member contacts.'); break; }
      if (!isGroupAdmin && !isOwner) { await reply('Group admins only.'); break; }
      try {
        const meta = await sock.groupMetadata(jid);
        const cards = (meta.participants || []).map((p, i) => {
          const n = String(p.id || p.jid || '').split('@')[0].split(':')[0].replace(/\D/g, '');
          if (!n) return '';
          return `BEGIN:VCARD\r\nVERSION:3.0\r\nFN:Group member ${i + 1}\r\nTEL;TYPE=CELL:+${n}\r\nEND:VCARD`;
        }).filter(Boolean);
        if (!cards.length) { await reply('No exportable phone-number contacts were returned.'); break; }
        await sock.sendMessage(jid, { document: Buffer.from(cards.join('\r\n'), 'utf8'), mimetype: 'text/vcard', fileName: `group-contacts-${Date.now()}.vcf` }, { quoted: m });
      } catch (e) { await reply(`Contact export failed: ${e.message}`); }
      break;
    }
    case 'write': {
      if (!text) { await reply('Usage: .write <text>'); break; }
      try {
        const sharp = require('sharp');
        const safe = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').slice(0, 500);
        const chunks = safe.match(/.{1,28}(?:\s|$)|.{1,28}/g) || [safe];
        const lines = chunks.slice(0, 8).map((line, i) => `<text x="500" y="${180 + i * 48}" text-anchor="middle" fill="white" font-family="sans-serif" font-size="38" font-weight="bold">${line.trim()}</text>`).join('');
        const svg = `<svg width="1000" height="500" xmlns="http://www.w3.org/2000/svg"><rect width="100%" height="100%" fill="#101820"/>${lines}</svg>`;
        const image = await sharp(Buffer.from(svg)).png().toBuffer();
        await sock.sendMessage(jid, { image, caption: 'Text image' }, { quoted: m });
      } catch (e) { await reply(`Could not create text image: ${e.message}`); }
      break;
    }
    default: return false;
  }
  return true;
}
module.exports = { referenceCommandHandler };
