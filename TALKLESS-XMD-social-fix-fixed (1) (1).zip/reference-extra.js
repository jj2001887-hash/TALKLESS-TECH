'use strict';
const axios = require('axios');
const path = require('path');
const { readJSON, writeJSON } = require('./helper/utils');
const DISABLED_FILE = path.resolve(__dirname, 'database', 'disabled-commands.json');
const NEWSLETTER_FILE = path.resolve(__dirname, 'database', 'newsletter-config.json');
const { setWaSetting } = require('./helper/function');
const { retrieveMessage } = require('./helper/function');
const { requestJid, findPendingRequest, applyJoinRequestAction, formatJoinRequestSummary } = require('./helper/groupRequests');

async function referenceExtraHandler(sock, m, cmd, args, h) {
  const { reply, replyImg, isOwner, isGroupAdmin, isBotAdmin, getQuoted } = h;
  const jid = m.key.remoteJid;
  const text = args.join(' ').trim();
  const isGroup = jid.endsWith('@g.us');
  const requireGroupAdmin = async (needBot = false) => {
    if (!isGroup) { await reply('This command must be used in a group.'); return false; }
    if (!isGroupAdmin) { await reply('❌ This command requires a group admin.'); return false; }
    if (needBot && !isBotAdmin) { await reply('Make the bot a group admin first.'); return false; }
    return true;
  };
  switch (cmd) {
    case 'disable':
    case 'enable': {
      if (!isOwner) { await reply('Owner only.'); break; }
      const target = String(args[0] || '').toLowerCase().replace(/[^a-z0-9_-]/g, '');
      if (!target || ['menu','enable','disable'].includes(target)) { await reply(`Usage: .${cmd} <command>. Core menu/enable/disable recovery commands cannot be disabled.`); break; }
      const data = readJSON(DISABLED_FILE, {});
      const waNum = String(sock.__waNum || 'default');
      const list = new Set(Array.isArray(data[waNum]) ? data[waNum] : []);
      if (cmd === 'disable') list.add(target); else list.delete(target);
      data[waNum] = [...list]; writeJSON(DISABLED_FILE, data);
      await reply(`${cmd === 'disable' ? '⛔ Disabled' : '✅ Enabled'} command: ${target}`);
      break;
    }
    case 'getsession': {
      if (!isOwner) { await reply('Owner only.'); break; }
      await reply(`Session: ${sock.__sessionId || 'unknown'}\nWhatsApp: +${String(sock.__waNum || '').replace(/\D/g, '') || 'unknown'}`);
      break;
    }
    case 'delete':
    case 'clean': {
      if (!isOwner) { await reply('Owner only.'); break; }
      const { qMsg, qKey } = getQuoted(m);
      if (!qMsg || !qKey?.id) { await reply('Reply to a message sent by this bot, then use .delete.'); break; }
      const botNums = new Set([sock.user?.id, sock.user?.lid].map(x => String(x || '').split('@')[0].split(':')[0].replace(/\D/g, '')).filter(Boolean));
      const quotedSender = qKey.participant || '';
      const cached = retrieveMessage(qKey.remoteJid || jid, qKey.id, sock.__waNum || 'default');
      const isBotMessage = qKey.fromMe || cached?.key?.fromMe === true || botNums.has(String(quotedSender).split('@')[0].split(':')[0].replace(/\D/g, ''));
      if (!isBotMessage) { await reply('For safety, this only deletes a message sent by this bot.'); break; }
      try { await sock.sendMessage(jid, { delete: { ...qKey, fromMe: true } }); }
      catch (e) { await reply(`Could not delete the quoted message: ${e.message}`); }
      break;
    }
    case 'forward': {
      if (!isOwner) { await reply('Owner only.'); break; }
      const { qMsg, qKey } = getQuoted(m);
      if (!qMsg) { await reply('Reply to the message you want forwarded. Usage: .forward <phone number or group JID>'); break; }
      const targetRaw = String(args[0] || '');
      const number = targetRaw.replace(/\D/g, '');
      const target = targetRaw.endsWith('@g.us') ? targetRaw : (number.length >= 7 && number.length <= 15 ? `${number}@s.whatsapp.net` : '');
      if (!target) { await reply('Provide a valid destination phone number or group JID.'); break; }
      if (typeof sock.copyNForward !== 'function') { await reply('Forwarding is unavailable in this WhatsApp library build.'); break; }
      try { await sock.copyNForward(target, { key: qKey, message: qMsg }, true); await reply(`✅ Forwarded to ${target}.`); }
      catch (e) { await reply(`Forward failed: ${e.message}`); }
      break;
    }
    case 'tostatus': {
      if (!isOwner) { await reply('Owner only.'); break; }
      const { qMsg, qType, qKey } = getQuoted(m);
      if (text) { await sock.sendMessage('status@broadcast', { text: text.slice(0, 700) }); await reply('✅ Text status posted.'); break; }
      const image = qType === 'imageMessage' ? await h.dlMedia({ imageMessage: qMsg.imageMessage }, qKey) : null;
      const video = qType === 'videoMessage' ? await h.dlMedia({ videoMessage: qMsg.videoMessage }, qKey) : null;
      if (!image && !video) { await reply('Use .tostatus <text> or reply to an image/video.'); break; }
      await sock.sendMessage('status@broadcast', image ? { image, caption: ' ' } : { video, caption: ' ' });
      await reply('✅ Media status posted.');
      break;
    }
    case 'killgc': {
      if (!(await requireGroupAdmin())) break;
      if (args[0]?.toUpperCase() !== 'CONFIRM') { await reply(`This makes the bot leave this group. Run ${h.cfg(sock).prefix || '.'}killgc CONFIRM to proceed.`); break; }
      try { await reply('👋 Leaving this group now.'); await sock.groupLeave(jid); }
      catch (e) { await reply(`Could not leave the group: ${e.message}`); }
      break;
    }
    case 'getgroupprofile': {
      if (!isGroup) { await reply('Use this command in a group.'); break; }
      try {
        const url = await sock.profilePictureUrl(jid, 'image');
        if (!url) { await reply('This group has no profile picture available.'); break; }
        const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 12000 });
        await replyImg(Buffer.from(res.data), 'Group profile picture');
      } catch (e) { await reply(`Could not get the group profile picture. Check the connection and try again.`); }
      break;
    }
    case 'setgroupprofile': {
      if (!(await requireGroupAdmin(true))) break;
      const { qMsg, qType, qKey } = getQuoted(m);
      let image = m.message?.imageMessage ? await h.dlMedia({ imageMessage: m.message.imageMessage }, m.key) : null;
      if (!image && qType === 'imageMessage') image = await h.dlMedia({ imageMessage: qMsg.imageMessage }, qKey);
      if (!image && /^https?:\/\//i.test(args[0] || '')) {
        const res = await axios.get(args[0], { responseType: 'arraybuffer', timeout: 15000 });
        image = Buffer.from(res.data);
      }
      if (!image) { await reply('Send/reply to an image or use .setgroupprofile <image URL>.'); break; }
      try {
        const sharp = require('sharp');
        image = await sharp(image).resize(640, 640, { fit: 'cover' }).jpeg({ quality: 88 }).toBuffer();
        await sock.updateProfilePicture(jid, image);
        await reply('✅ Group profile picture updated.');
      } catch (e) { await reply(`Could not update the group picture: ${e.message}`); }
      break;
    }
    case 'approve':
    case 'reject': {
      if (!(await requireGroupAdmin(true))) break;
      if (typeof sock.groupRequestParticipantsList !== 'function' || typeof sock.groupRequestParticipantsUpdate !== 'function') {
        await reply('❌ This WhatsApp library does not support group join-request management.');
        break;
      }
      const input = String(args[0] || '').trim();
      if (!input) { await reply(`Usage: .${cmd} <pending number> | all\nTip: .checkpending lists current requests.`); break; }
      try {
        const pending = await sock.groupRequestParticipantsList(jid);
        if (!Array.isArray(pending)) throw new Error('WhatsApp returned an invalid pending-request list.');
        const action = cmd === 'approve' ? 'approve' : 'reject';
        if (input.toLowerCase() === 'all') {
          const jids = pending.map(requestJid).filter(Boolean);
          const result = await applyJoinRequestAction(sock, jid, jids, action);
          await reply(formatJoinRequestSummary(result, action));
          break;
        }
        const digits = input.replace(/\D/g, '');
        if (!input.includes('@') && !/^\d{7,15}$/.test(digits)) {
          await reply(`❌ Usage: .${cmd} <international number> | all`);
          break;
        }
        const request = findPendingRequest(pending, input);
        if (!request) {
          await reply(`📭 No matching pending request for ${input.includes('@') ? input : `+${digits}`}. Use .checkpending to refresh the list.`);
          break;
        }
        const targetJid = requestJid(request);
        if (!targetJid) throw new Error('Could not identify that pending request. Refresh the list and try again.');
        const result = await applyJoinRequestAction(sock, jid, [targetJid], action);
        const person = digits ? `+${digits}` : targetJid;
        await reply(result.succeeded === 1
          ? `✅ Request ${action === 'approve' ? 'approved' : 'rejected'}\n👤 ${person}`
          : `❌ Could not ${action} the request for ${person}.\n${formatJoinRequestSummary(result, action)}`);
      } catch (e) { await reply(`Could not ${cmd} request: ${e.message}`); }
      break;
    }
    case 'demoteall': {
      if (!(await requireGroupAdmin(true))) break;
      if (args[0]?.toUpperCase() !== 'CONFIRM') { await reply(`This will remove admin status from every other admin. To proceed, run ${h.cfg(sock).prefix || '.'}demoteall CONFIRM.`); break; }
      try {
        const meta = await sock.groupMetadata(jid);
        const own = new Set([sock.user?.id, sock.user?.lid].map(v => String(v || '').split('@')[0].split(':')[0].replace(/\D/g, '')).filter(Boolean));
        const superAdmin = meta.participants?.find(p => p.admin === 'superadmin');
        const protectedNums = new Set([...own, String(superAdmin?.id || '').split('@')[0].replace(/\D/g, '')].filter(Boolean));
        const targets = (meta.participants || []).filter(p => p.admin && !protectedNums.has(String(p.id || p.jid || '').split('@')[0].split(':')[0].replace(/\D/g, ''))).map(p => p.id || p.jid).filter(Boolean);
        if (!targets.length) { await reply('No eligible group admins to demote.'); break; }
        for (const target of targets) await sock.groupParticipantsUpdate(jid, [target], 'demote');
        await reply(`✅ Demoted ${targets.length} admin(s). The bot and group owner were excluded.`);
      } catch (e) { await reply(`Demote-all failed: ${e.message}`); }
      break;
    }
    case 'invite': {
      if (!(await requireGroupAdmin())) break;
      try {
        if (typeof sock.groupInviteCode !== 'function') throw new Error('Group invite links are unavailable in this WhatsApp library.');
        const code = await sock.groupInviteCode(jid);
        if (!code) throw new Error('WhatsApp returned an empty invite code.');
        await reply(`Group invite: https://chat.whatsapp.com/${code}`);
      } catch (e) { await reply(`Could not get the invite link. Check group permissions and try again.`); }
      break;
    }
    case 'join': {
      if (!isOwner) { await reply('Owner only.'); break; }
      const code = (text.match(/chat\.whatsapp\.com\/([A-Za-z0-9_-]+)/i) || [])[1] || text;
      if (!/^[A-Za-z0-9_-]{8,}$/.test(code)) { await reply('Usage: .join <WhatsApp group invite link or invite code>'); break; }
      try {
        const joined = await sock.groupAcceptInvite(code);
        await reply(`✅ Joined group ${joined || ''}`);
      } catch (e) { await reply(`Could not join that group: ${e.message}`); }
      break;
    }
    case 'disp':
    case 'groupstatus': {
      if (!isGroup) { await reply('Use this command in a group.'); break; }
      try {
        const meta = await sock.groupMetadata(jid);
        const admins = (meta.participants || []).filter(p => p.admin).length;
        await reply(`*Group status*\nName: ${meta.subject || '(unnamed)'}\nMembers: ${(meta.participants || []).length}\nAdmins: ${admins}\nDescription: ${meta.desc || '(none)'}`);
      } catch (e) { await reply(`Could not read group status: ${e.message}`); }
      break;
    }
    case 'mygroups': {
      if (!isOwner) { await reply('Owner only.'); break; }
      if (typeof sock.groupFetchAllParticipating !== 'function') { await reply('This WhatsApp library does not support fetching all joined groups.'); break; }
      try {
        const groups = await sock.groupFetchAllParticipating();
        const rows = Object.entries(groups || {}).map(([id, g]) => `${g.subject || 'Unnamed'} — ${id}`);
        await reply(rows.length ? `*Groups (${rows.length})*\n\n${rows.slice(0, 80).join('\n')}` : 'No groups found.');
      } catch (e) { await reply(`Could not list groups: ${e.message}`); }
      break;
    }
    case 'creategc': {
      if (!isOwner) { await reply('Owner only.'); break; }
      const title = args.slice(0, args.findIndex(x => /^\+?\d{7,15}$/.test(x)) < 0 ? undefined : args.findIndex(x => /^\+?\d{7,15}$/.test(x))).join(' ').trim();
      const numbers = args.filter(x => /^\+?\d{7,15}$/.test(x)).map(x => `${x.replace(/\D/g, '')}@s.whatsapp.net`);
      if (!title) { await reply('Usage: .creategc <group name> [participant numbers...]'); break; }
      if (typeof sock.groupCreate !== 'function') { await reply('Group creation is not supported by this WhatsApp library.'); break; }
      try {
        const result = await sock.groupCreate(title, numbers);
        await reply(`✅ Created group *${title}*\nID: ${result?.id || 'created'}`);
      } catch (e) { await reply(`Could not create group: ${e.message}`); }
      break;
    }
    case 'setpack': {
      if (!isOwner) { await reply('Owner only.'); break; }
      const [pack, author] = text.split('|').map(x => x.trim());
      if (!pack) { await reply('Usage: .setpack <pack name> | <author>'); break; }
      const session = sock.__waNum || sock.user?.id?.split('@')[0] || 'default';
      setWaSetting(session, 'stickerPackName', pack.slice(0, 60));
      if (author) setWaSetting(session, 'stickerPackAuthor', author.slice(0, 60));
      await reply(`✅ Sticker pack set to *${pack}*${author ? ` by ${author}` : ''}.`);
      break;
    }
    case 'alwaysonline':
    case 'autodownloadstatus':
    case 'automedia':
    case 'autopacksticker': {
      if (!isOwner) { await reply('Owner only.'); break; }
      const v = args[0]?.toLowerCase();
      const key = { alwaysonline:'alwaysOnline', autodownloadstatus:'autoDownloadStatus', automedia:'autoMedia', autopacksticker:'autoPackSticker' }[cmd];
      if (!['on','off'].includes(v)) { await reply(`Usage: .${cmd} on/off`); break; }
      setWaSetting(sock.__waNum || 'default', key, v === 'on');
      if (cmd === 'alwaysonline' && v === 'on') { try { await sock.sendPresenceUpdate('available'); } catch {} }
      if (cmd === 'alwaysonline' && v === 'off') { try { await sock.sendPresenceUpdate('unavailable'); } catch {} }
      await reply(`✅ ${cmd}: ${v.toUpperCase()}`);
      break;
    }
    case 'autostatusemoji': {
      if (!isOwner) { await reply('Owner only.'); break; }
      const emoji = text.trim();
      if (!emoji || [...emoji].length > 8) { await reply('Usage: .autostatusemoji <emoji>'); break; }
      setWaSetting(sock.__waNum || 'default', 'autoReactEmoji', emoji);
      setWaSetting(sock.__waNum || 'default', 'autoReact', true);
      await reply(`✅ Status reactions will use ${emoji}. Use .autoreact off to disable.`);
      break;
    }
    case 'settimezone': {
      if (!isOwner) { await reply('Owner only.'); break; }
      try { new Intl.DateTimeFormat('en', { timeZone: text }).format(new Date()); }
      catch { await reply('Use a valid IANA timezone, for example Europe/London or Africa/Nairobi.'); break; }
      setWaSetting(sock.__waNum || 'default', 'timezone', text);
      await reply(`✅ Timezone set to ${text}.`);
      break;
    }
    case 'savestatus': {
      const { qMsg, qType, qKey } = getQuoted(m);
      if (!qMsg) { await reply('Reply to a WhatsApp status and use .savestatus.'); break; }
      try {
        if (qType === 'imageMessage') {
          const b = await h.dlMedia({ imageMessage: qMsg.imageMessage }, qKey);
          await sock.sendMessage(jid, { image: b, caption: qMsg.imageMessage.caption || '' }, { quoted: m });
        } else if (qType === 'videoMessage') {
          const b = await h.dlMedia({ videoMessage: qMsg.videoMessage }, qKey);
          await sock.sendMessage(jid, { video: b, caption: qMsg.videoMessage.caption || '' }, { quoted: m });
        } else if (qType === 'audioMessage') {
          const b = await h.dlMedia({ audioMessage: qMsg.audioMessage }, qKey);
          await sock.sendMessage(jid, { audio: b, mimetype: qMsg.audioMessage.mimetype || 'audio/ogg' }, { quoted: m });
        } else {
          const text = qMsg.conversation || qMsg.extendedTextMessage?.text;
          if (!text) throw new Error('Unsupported status content.');
          await reply(text);
        }
      } catch (e) { await reply(`Could not save status: ${e.message}`); }
      break;
    }
    case 'newsletter': {
      const data = readJSON(NEWSLETTER_FILE, {});
      const list = data[String(sock.__waNum || 'default')] || [];
      await reply(list.length ? `Followed newsletters:\n${list.join('\n')}` : 'No newsletters configured for this bot session. Use .setnewsletter <newsletter JID>.');
      break;
    }
    case 'setnewsletter': {
      if (!isOwner) { await reply('Owner only.'); break; }
      const newsletterJid = String(args[0] || '').trim();
      if (!/@newsletter$/.test(newsletterJid)) { await reply('Usage: .setnewsletter <newsletter JID ending in @newsletter>'); break; }
      if (typeof sock.newsletterFollow !== 'function') { await reply('Newsletter follow is not supported by this WhatsApp library.'); break; }
      try {
        await sock.newsletterFollow(newsletterJid);
        const data = readJSON(NEWSLETTER_FILE, {}); const id = String(sock.__waNum || 'default');
        data[id] = [...new Set([...(Array.isArray(data[id]) ? data[id] : []), newsletterJid])]; writeJSON(NEWSLETTER_FILE, data);
        await reply(`✅ Followed newsletter ${newsletterJid}.`);
      } catch (e) { await reply(`Could not follow newsletter: ${e.message}`); }
      break;
    }
    case 'calllink': {
      if (!isOwner) { await reply('Owner only.'); break; }
      if (typeof sock.createCallLink !== 'function') { await reply('Call-link creation is not available in this WhatsApp library version.'); break; }
      try {
        const type = args[0]?.toLowerCase() === 'video' ? 'video' : 'audio';
        const result = await sock.createCallLink(type, Math.floor(Date.now() / 1000));
        const link = typeof result === 'string' ? result : result?.link || result?.callLink;
        await reply(link ? `☎️ ${type} call link: ${link}` : 'WhatsApp did not return a call link.');
      } catch (e) { await reply(`Could not create call link: ${e.message}`); }
      break;
    }
    case 'listonline':
    case 'listoffline':
    case 'kickactive': {
      if (!(await requireGroupAdmin(cmd === 'kickactive'))) break;
      const meta = await sock.groupMetadata(jid).catch(() => null);
      if (!meta) { await reply('Could not read group membership.'); break; }
      try {
        for (const member of meta.participants || []) {
          try { const pending = sock.presenceSubscribe?.(member.id || member.jid); pending?.catch?.(() => {}); } catch {}
        }
      } catch {}
      await new Promise(resolve => setTimeout(resolve, 1200));
      const states = sock.__presenceByChat?.get(jid) || new Map();
      const selected = (meta.participants || []).filter(p => {
        if (p.admin) return false;
        const id = p.id || p.jid;
        const state = states.get(id) || states.get(String(id).split('@')[0]);
        return cmd === 'listonline' ? state === 'available' : cmd === 'listoffline' ? state === 'unavailable' : state === 'available';
      });
      if (cmd === 'kickactive') {
        if (args[0]?.toUpperCase() !== 'CONFIRM') { await reply(`This removes ${selected.length} presence-detected active non-admin member(s). Run .kickactive CONFIRM to proceed.`); break; }
        if (!selected.length) { await reply('No active non-admin members were detected.'); break; }
        let removed = 0, failed = 0;
        for (const p of selected) {
          try {
            const result = await sock.groupParticipantsUpdate(jid, [p.id || p.jid], 'remove');
            if (Array.isArray(result) && result.length && result.every(item => String(item?.status || '') === '200')) removed++;
            else failed++;
          } catch { failed++; }
        }
        await reply(`🧹 *Active-member cleanup*\n✅ Removed: ${removed}\n❌ Failed: ${failed}\nℹ️ Online status uses available WhatsApp presence snapshots.`);
      } else {
        await reply(selected.length ? `${cmd === 'listonline' ? 'Presence-online' : 'Presence-offline'} members (${selected.length}):\n${selected.map(p => `+${String(p.id || p.jid).split('@')[0]}`).join('\n')}` : `No ${cmd === 'listonline' ? 'online' : 'offline'} presence snapshots are currently available. WhatsApp may not expose presence for every member.`);
      }
      break;
    }
    case 'setownernumber': {
      if (!isOwner) { await reply('Owner only.'); break; }
      const number = String(args[0] || '').replace(/\D/g, '');
      if (number.length < 7 || number.length > 15) { await reply('Usage: .setownernumber <country code + number>'); break; }
      setWaSetting(sock.__waNum || 'default', 'owner', number);
      await reply(`✅ Owner number updated to +${number}.`);
      break;
    }
    default: return false;
  }
  return true;
}
module.exports = { referenceExtraHandler };
