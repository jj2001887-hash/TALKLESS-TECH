// ============================================================
//   start.js — supervisor for panel hosting
//
//   Pterodactyl only restarts a server when the startup process
//   exits AND the egg enables crash detection. Many eggs (and most
//   free hosts) do not, so a single unhandled crash leaves the
//   server "off" until someone starts it by hand.
//
//   This wrapper never exits: it forks index.js, waits for it, and
//   restarts it with backoff. It also prints WHY the child died —
//   `signal SIGKILL` is the fingerprint of a memory-limit kill,
//   which no amount of restarting can fix.
//
//   Panel startup command:  node start.js
// ============================================================
'use strict';

const { spawn } = require('child_process');

const ENTRY       = process.argv[2] || 'index.js';
const MIN_DELAY   = 1_000;
const MAX_DELAY   = 30_000;
const STABLE_MS   = 60_000;   // ran this long ⇒ treat as a healthy run, reset backoff
const LOOP_WINDOW = 300_000;  // crash-loop window
const LOOP_LIMIT  = 5;

let child     = null;
let backoff   = MIN_DELAY;
let startedAt = 0;
let stopping  = false;
const exits   = [];

const stamp = () => new Date().toISOString().slice(11, 19);
const log   = (msg) => process.stdout.write(`[${stamp()}] [SUPERVISOR] ${msg}\n`);

function start() {
  startedAt = Date.now();
  child = spawn(process.execPath, [ENTRY, ...process.argv.slice(3)], {
    stdio: 'inherit',
    env: { ...process.env, __SUPERVISED: '1' },
  });

  log(`started ${ENTRY} (pid ${child.pid})`);

  child.on('error', (err) => {
    log(`could not spawn ${ENTRY}: ${err.message} — retrying in 5s`);
    setTimeout(start, 5_000);
  });

  child.on('exit', (code, signal) => {
    const ranSec = Math.round((Date.now() - startedAt) / 1000);

    if (stopping) {
      log(`child stopped (${signal || `code ${code}`}) — supervisor exiting`);
      process.exit(0);
    }

    log(`child exited — ${signal ? `signal ${signal}` : `code ${code}`}, ran ${ranSec}s`);

    if (signal === 'SIGKILL') {
      log('SIGKILL almost always means the panel hit the memory limit.');
      log('Raise Memory in Startup/Resources, or cut the number of live sessions.');
    } else if (code === 0) {
      log('Exit code 0: the process ended normally (idle stop, SIGTERM handler, or a manual stop inside the bot).');
    } else if (code === 42) {
      log('Exit code 42: deliberate self-restart (memory watchdog).');
    }

    if ((Date.now() - startedAt) >= STABLE_MS) backoff = MIN_DELAY;

    exits.push(Date.now());
    while (exits.length && Date.now() - exits[0] > LOOP_WINDOW) exits.shift();

    let delay = backoff;
    if (exits.length >= LOOP_LIMIT) {
      delay = 60_000;
      log(`crash loop: ${exits.length} exits in 5 min — pausing 60s before the next start`);
    } else {
      log(`restarting in ${Math.round(delay / 1000)}s`);
    }

    setTimeout(start, delay);
    backoff = Math.min(backoff * 2, MAX_DELAY);
  });
}

for (const sig of ['SIGTERM', 'SIGINT']) {
  process.on(sig, () => {
    if (stopping) return;
    stopping = true;
    log(`${sig} received — stopping child`);
    if (child && child.exitCode === null) child.kill(sig);
    // Panels give ~10s before SIGKILL; don't hang the shutdown.
    const force = setTimeout(() => process.exit(0), 8_000);
    force.unref?.();
  });
}

start();
