// stickers.js – 30+ Sticker/Media Commands
'use strict';
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const stickerLib = require('./helper/sticker');
const botSettings = require('./settings');
const { setWaSetting } = require('./helper/function');

const STICKER_CMDS = [
  'sticker2','tomp4sticker','stickerinfo','attp2','emojisticker',
  'gifsticker','videosticker','cropsticker','circleimg',
  'givensticker','colorsticker','textimg','imagetext',
  'tenor','giphy','gifcat','gifdog','gifanime','gifyeet',
  'take','stealsticker','packname','packauthor','exifsticker',
  'save','savedstickers','getsticker','deletesticker',
  'togif','giftext','gifmeme','randgif','animegif',
  'memetemplate','randmeme',
];


// ── Shared sticker helpers ───────────────────────────────────
function unwrapMsg(message) {
  let value = message || {};
  for (let i = 0; i < 5; i++) {
    const w = ['ephemeralMessage', 'viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension', 'documentWithCaptionMessage']
      .find(n => value?.[n]?.message);
    if (!w) break;
    value = value[w].message;
  }
  return value;
}

function packOf(c) {
  return {
    pack: c.stickerPackName || c.botName || botSettings.BOT_NAME || 'TALKLESS ULTRA',
    author: c.stickerPackAuthor || botSettings.CREDITS || 'TALKLESS',
  };
}

// Finds image / video / sticker in the message itself or in the replied-to message.
function findMedia(m, helpers) {
  const { qMsg, qKey } = helpers.getQuoted(m);
  const inner = qMsg ? unwrapMsg(qMsg) : {};
  const own = unwrapMsg(m.message);
  const pick = (type) => {
    if (own?.[type]) return { src: { [type]: own[type] }, key: m.key, node: own[type] };
    if (inner?.[type]) return { src: { [type]: inner[type] }, key: qKey, node: inner[type] };
    return null;
  };
  return {
    image: pick('imageMessage'),
    video: pick('videoMessage'),
    sticker: pick('stickerMessage'),
  };
}

async function sendSticker(sock, jid, m, buf) {
  return sock.sendMessage(jid, { sticker: buf }, { quoted: m });
}

async function stickerHandler(sock, m, cmd, args, helpers) {
  if (!STICKER_CMDS.includes(cmd)) return false;
  const { reply, ft, cfg, reaction } = helpers;
  const jid    = m.key.remoteJid;
  const prefix = cfg(sock).prefix || '.';
  const text   = args.join(' ');

  switch (cmd) {
    // ── Media -> sticker family ──────────────────────────────
    case 'sticker2':
    case 'cropsticker':
    case 'gifsticker':
    case 'videosticker': {
      const media = findMedia(m, helpers);
      const wantVideo = cmd === 'gifsticker' || cmd === 'videosticker';
      const found = wantVideo ? (media.video || media.sticker) : (media.image || media.video || media.sticker);
      if (!found) {
        await reply(`🎨 *${prefix}${cmd}* — reply to ${wantVideo ? 'a video or GIF' : 'an image, video or sticker'}.`);
        break;
      }
      reaction('🎨');
      try {
        const buf = await helpers.dlMedia(found.src, found.key);
        const { pack, author } = packOf(cfg(sock));
        const webp = await stickerLib.makeSticker(buf, {
          isVideo: !!found.src.videoMessage,
          crop: cmd === 'cropsticker',
          pack, author,
        });
        await sendSticker(sock, jid, m, webp);
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'take':
    case 'stealsticker':
    case 'exifsticker': {
      const { sticker } = findMedia(m, helpers);
      if (!sticker) { await reply(`🕵️ Reply to a sticker with *${prefix}${cmd} <pack> | <author>*`); break; }
      try {
        const buf = await helpers.dlMedia(sticker.src, sticker.key);
        const defaults = packOf(cfg(sock));
        const [pk, au] = text.split('|').map(v => v.trim());
        const webp = await stickerLib.makeSticker(buf, { pack: pk || defaults.pack, author: au || defaults.author });
        await sendSticker(sock, jid, m, webp);
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'save': {
      const { sticker } = findMedia(m, helpers);
      if (!sticker) { await reply(`📥 Reply to a sticker with *${prefix}save* to save it in this bot's sticker library.`); break; }
      try {
        const buf = await helpers.dlMedia(sticker.src, sticker.key);
        const dir = path.resolve(__dirname, 'database', 'sticker-saves', String(sock.__waNum || 'default').replace(/[^0-9A-Za-z_-]/g, ''));
        fs.mkdirSync(dir, { recursive: true });
        const id = Date.now().toString(36);
        fs.writeFileSync(path.join(dir, `${id}.webp`), buf);
        await reply(`✅ Sticker saved as *${id}*. Retrieve it with *${prefix}getsticker ${id}* or view your saved stickers with *${prefix}savedstickers*.`);
      } catch (e) { await reply(`❌ Could not save sticker: ${e.message}`); }
      break;
    }
    case 'savedstickers': {
      const dir = path.resolve(__dirname, 'database', 'sticker-saves', String(sock.__waNum || 'default').replace(/[^0-9A-Za-z_-]/g, ''));
      let ids = [];
      try { ids = fs.readdirSync(dir).filter(name => /^[a-z0-9_-]+\.webp$/i.test(name)).map(name => name.slice(0, -5)).sort().reverse(); } catch {}
      await reply(ids.length ? `📚 *Saved stickers (${ids.length})*\n${ids.slice(0, 60).map((id, i) => `${i + 1}. ${id}`).join('\n')}${ids.length > 60 ? '\n…showing latest 60' : ''}` : `No saved stickers yet. Reply to a sticker with *${prefix}save*.`);
      break;
    }
    case 'getsticker': {
      const id = String(args[0] || '').trim();
      if (!/^[a-z0-9_-]{1,32}$/i.test(id)) { await reply(`Usage: *${prefix}getsticker <id>* — use *${prefix}savedstickers* to see IDs.`); break; }
      const file = path.resolve(__dirname, 'database', 'sticker-saves', String(sock.__waNum || 'default').replace(/[^0-9A-Za-z_-]/g, ''), `${id}.webp`);
      try { await sendSticker(sock, jid, m, fs.readFileSync(file)); }
      catch { await reply('❌ Sticker not found in this bot session’s saved library.'); }
      break;
    }
    case 'deletesticker': {
      const id = String(args[0] || '').trim();
      if (!/^[a-z0-9_-]{1,32}$/i.test(id)) { await reply(`Usage: *${prefix}deletesticker <id>*`); break; }
      const file = path.resolve(__dirname, 'database', 'sticker-saves', String(sock.__waNum || 'default').replace(/[^0-9A-Za-z_-]/g, ''), `${id}.webp`);
      try { fs.unlinkSync(file); await reply(`🗑️ Deleted saved sticker *${id}*.`); }
      catch { await reply('❌ Sticker not found in this bot session’s saved library.'); }
      break;
    }
    case 'stickerinfo': {
      const { sticker } = findMedia(m, helpers);
      if (!sticker) { await reply(`ℹ️ Reply to a sticker with *${prefix}stickerinfo*`); break; }
      try {
        const buf = await helpers.dlMedia(sticker.src, sticker.key);
        const info = stickerLib.readPackInfo(buf) || {};
        const n = sticker.node || {};
        await reply(
          `🧾 *STICKER INFO*\n\n` +
          `📦 Pack: ${info['sticker-pack-name'] || 'none'}\n` +
          `✍️ Author: ${info['sticker-pack-publisher'] || 'none'}\n` +
          `🎞 Animated: ${stickerLib.webpIsAnimated(buf) || n.isAnimated ? 'yes' : 'no'}\n` +
          `📐 Size: ${n.width || '?'}×${n.height || '?'}\n` +
          `💾 File: ${(buf.length / 1024).toFixed(1)} KB`
        );
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'togif':
    case 'tomp4sticker': {
      const { sticker } = findMedia(m, helpers);
      if (!sticker) { await reply(`🎞 Reply to a sticker with *${prefix}${cmd}*`); break; }
      try {
        const buf = await helpers.dlMedia(sticker.src, sticker.key);
        const out = await stickerLib.stickerToMedia(buf);
        if (out.type === 'video') {
          await sock.sendMessage(jid, { video: out.buffer, gifPlayback: true, caption: ft('🎞 Done', sock) }, { quoted: m });
        } else {
          await sock.sendMessage(jid, { image: out.buffer, caption: ft('🖼 This sticker is not animated — sent as an image.', sock) }, { quoted: m });
        }
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    // ── Text / emoji / colour stickers (generated locally) ───
    case 'attp2': {
      if (!text) { await reply(`✨ *${prefix}attp2 <text>*`); break; }
      try {
        const { pack, author } = packOf(cfg(sock));
        await sendSticker(sock, jid, m, stickerLib.addExif(await stickerLib.textToWebp(text), pack, author));
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'colorsticker': {
      const color = (args[0] || '').trim() || '#' + Math.floor(Math.random() * 0xffffff).toString(16).padStart(6, '0');
      try {
        const { pack, author } = packOf(cfg(sock));
        await sendSticker(sock, jid, m, stickerLib.addExif(await stickerLib.colorToWebp(color), pack, author));
      } catch { await reply(`🎨 *${prefix}colorsticker <color>* — e.g. red, #ff8800`); }
      break;
    }
    case 'emojisticker': {
      const emoji = [...(text || '')].find(ch => /\p{Extended_Pictographic}/u.test(ch));
      if (!emoji) { await reply(`😀 *${prefix}emojisticker <emoji>*`); break; }
      try {
        const code = [...emoji].map(ch => ch.codePointAt(0).toString(16)).filter(c => c !== 'fe0f').join('_');
        const res = await axios.get(
          `https://raw.githubusercontent.com/googlefonts/noto-emoji/main/png/512/emoji_u${code}.png`,
          { responseType: 'arraybuffer', timeout: 10000 }
        );
        const { pack, author } = packOf(cfg(sock));
        await sendSticker(sock, jid, m, await stickerLib.makeSticker(Buffer.from(res.data), { pack, author }));
      } catch { await reply('❌ Could not find that emoji.'); }
      break;
    }
    // ── Pack name / author (owner) ───────────────────────────
    case 'packname':
    case 'packauthor': {
      if (!helpers.isOwner) { await reply('❌ Owner only.'); break; }
      if (!text) { await reply(`📦 *${prefix}${cmd} <text>*`); break; }
      setWaSetting(sock.__waNum, cmd === 'packname' ? 'stickerPackName' : 'stickerPackAuthor', text.slice(0, 60));
      await reply(`✅ Sticker ${cmd === 'packname' ? 'pack name' : 'author'} set to: ${text.slice(0, 60)}`);
      break;
    }
    case 'imagetext':
    case 'givensticker':
    case 'giftext':
    case 'gifmeme': {
      await reply(`⚠️ *${prefix}${cmd}* is not available yet.`);
      break;
    }
    case 'tenor': {
      if (!text) { await reply(`🎬 *${prefix}tenor <search term>*`); break; }
      await reaction('🎬');
      try {
        const { data } = await axios.get(
          `https://tenor.googleapis.com/v2/search?q=${encodeURIComponent(text)}&key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCY8&limit=1`,
          { timeout: 8000 }
        );
        const gifUrl = data?.results?.[0]?.media_formats?.gif?.url || data?.results?.[0]?.media_formats?.mediumgif?.url;
        if (!gifUrl) throw new Error('No GIF found');
        const res = await axios.get(gifUrl, { responseType: 'arraybuffer', timeout: 12000 });
        await sock.sendMessage(jid, {
          video: Buffer.from(res.data),
          gifPlayback: true,
          caption: ft(`🎬 ${text}`, sock),
        }, {});
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'giphy': {
      if (!text) { await reply(`🎭 *${prefix}giphy <search term>*`); break; }
      await reaction('🎭');
      try {
        const { data } = await axios.get(
          `https://api.giphy.com/v1/gifs/search?q=${encodeURIComponent(text)}&api_key=dc6zaTOxFJmzC&limit=1`,
          { timeout: 8000 }
        );
        const gifUrl2 = data?.data?.[0]?.images?.original?.url;
        if (!gifUrl2) throw new Error('No GIF found');
        const res2 = await axios.get(gifUrl2, { responseType: 'arraybuffer', timeout: 12000 });
        await sock.sendMessage(jid, {
          video: Buffer.from(res2.data),
          gifPlayback: true,
          caption: ft(`🎭 ${text}`, sock),
        }, {});
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'gifcat': {
      await reaction('🐱');
      try {
        const { data } = await axios.get('https://api.thecatapi.com/v1/images/search?mime_types=gif', { timeout: 8000 });
        const url = data?.[0]?.url;
        if (!url) throw new Error('No cat GIF');
        const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 12000 });
        await sock.sendMessage(jid, { video: Buffer.from(res.data), gifPlayback: true, caption: ft('🐱 Cat GIF~', sock) }, {});
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'gifdog': {
      await reaction('🐶');
      try {
        const { data } = await axios.get('https://random.dog/woof.json?include=gif', { timeout: 8000 });
        const url2 = data?.url;
        if (!url2) throw new Error('No dog GIF');
        const res2 = await axios.get(url2, { responseType: 'arraybuffer', timeout: 12000 });
        await sock.sendMessage(jid, { video: Buffer.from(res2.data), gifPlayback: true, caption: ft('🐶 Dog GIF~', sock) }, {});
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'gifanime': {
      await reaction('🎌');
      try {
        const cats = ['waifu','neko','shinobu','megumin','blush','smile','wave','dance','happy'];
        const cat  = text || cats[Math.floor(Math.random()*cats.length)];
        const { data } = await axios.get(`https://api.waifu.pics/sfw/${cat}`, { timeout: 8000 });
        await sock.sendMessage(jid, { image: { url: data.url }, caption: ft(`🎌 ${cat}`, sock) }, {});
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'randgif': {
      await reaction('🎲');
      try {
        const terms = ['funny','cute','wow','awesome','anime','cat','dog','meme','cool'];
        const term  = terms[Math.floor(Math.random()*terms.length)];
        const { data } = await axios.get(
          `https://api.giphy.com/v1/gifs/random?tag=${term}&api_key=dc6zaTOxFJmzC`,
          { timeout: 8000 }
        );
        const url3 = data?.data?.images?.original?.url;
        if (!url3) throw new Error('No GIF');
        const res3 = await axios.get(url3, { responseType: 'arraybuffer', timeout: 12000 });
        await sock.sendMessage(jid, { video: Buffer.from(res3.data), gifPlayback: true, caption: ft(`🎲 Random GIF: ${term}`, sock) }, {});
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'animegif': {
      await reaction('⛩️');
      try {
        const { data } = await axios.get('https://api.waifu.pics/sfw/waifu', { timeout: 8000 });
        await sock.sendMessage(jid, { image: { url: data.url }, caption: ft('⛩️ Anime~', sock) }, {});
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'gifyeet': {
      await reaction('🚀');
      try {
        const { data } = await axios.get('https://api.giphy.com/v1/gifs/random?tag=yeet&api_key=dc6zaTOxFJmzC', { timeout: 8000 });
        const url4 = data?.data?.images?.original?.url;
        const res4 = await axios.get(url4, { responseType: 'arraybuffer', timeout: 12000 });
        await sock.sendMessage(jid, { video: Buffer.from(res4.data), gifPlayback: true, caption: ft('🚀 YEET!', sock) }, {});
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'memetemplate': {
      await reaction('😂');
      const templates = [
        { name: 'Drake', url: 'https://i.imgflip.com/30b1gx.jpg' },
        { name: 'Distracted Boyfriend', url: 'https://i.imgflip.com/1ur9b0.jpg' },
        { name: 'Change My Mind', url: 'https://i.imgflip.com/24y43o.jpg' },
        { name: 'Two Buttons', url: 'https://i.imgflip.com/1g8my4.jpg' },
        { name: 'Expanding Brain', url: 'https://i.imgflip.com/1jwhww.jpg' },
        { name: 'Waiting Skeleton', url: 'https://i.imgflip.com/2fm6x.jpg' },
        { name: 'Is This a Pigeon', url: 'https://i.imgflip.com/1o00in.jpg' },
        { name: 'This is Fine', url: 'https://i.imgflip.com/wxica.jpg' },
      ];
      const template = text
        ? templates.find(t => t.name.toLowerCase().includes(text.toLowerCase())) || templates[0]
        : templates[Math.floor(Math.random() * templates.length)];
      await sock.sendMessage(jid, {
        image: { url: template.url },
        caption: ft(`😂 *${template.name}* meme template\n\nUse ${prefix}meme2 to add text`, sock),
      }, {});
      break;
    }
    case 'randmeme': {
      await reaction('😂');
      try {
        const { data } = await axios.get('https://meme-api.com/gimme', { timeout: 8000 });
        await sock.sendMessage(jid, {
          image: { url: data.url },
          caption: ft(`😂 *${data.title}*\n\n⬆️ ${data.ups?.toLocaleString() || '?'} upvotes | r/${data.subreddit}`, sock),
        }, {});
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'textimg': {
      if (!text) { await reply(`📝 *${prefix}textimg <your text>*\nConverts text to an image card.`); break; }
      await reaction('📝');
      try {
        const { data } = await axios.get(
          `https://api.popcat.xyz/textpic?text=${encodeURIComponent(text.slice(0,100))}`,
          { responseType: 'arraybuffer', timeout: 10000 }
        );
        await sock.sendMessage(jid, { image: Buffer.from(data), caption: ft(`📝 ${text}`, sock) }, {});
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'circleimg': {
      await reaction('⭕');
      const qmsg = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (!qmsg?.imageMessage) { await reply(`⭕ Reply to an image with *${prefix}circleimg*`); break; }
      try {
        const { downloadMediaMessage } = require('blacklord-baileys');
        const buf = await downloadMediaMessage(
          { message: qmsg, key: { remoteJid: jid, id: m.message?.extendedTextMessage?.contextInfo?.stanzaId, fromMe: false } },
          'buffer', {},
          { logger: { info(){}, error(){}, warn(){}, debug(){}, child(){ return this; } } }
        );
        const sharp = require('sharp');
        const meta  = await sharp(buf).metadata();
        const size  = Math.min(meta.width||400, meta.height||400);
        const mask  = Buffer.from(`<svg><circle cx="${size/2}" cy="${size/2}" r="${size/2}"/></svg>`);
        const result = await sharp(buf)
          .resize(size, size, { fit: 'cover' })
          .composite([{ input: mask, blend: 'dest-in' }])
          .png()
          .toBuffer();
        await sock.sendMessage(jid, { image: result, caption: ft('⭕ Circle crop!', sock) }, {});
      } catch { await reply(`❌ sharp not installed. Run: npm install sharp`); }
      break;
    }
    default:
      await reply(ft(`⚠️ *${prefix}${cmd}* — Reply to an image/video to use this command.`, sock));
      return false;
  }
  return true;
}

module.exports = { stickerHandler };
